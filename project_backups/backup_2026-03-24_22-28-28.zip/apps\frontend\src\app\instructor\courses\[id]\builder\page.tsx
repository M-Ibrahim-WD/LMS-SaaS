"use client";

import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { FormEvent, useState } from "react";
import { apiFetch } from "../../../../../lib/api/client";
import { BackButton } from "../../../../../components/back-button";
import { useRequireAuth } from "../../../../../hooks/use-require-auth";

interface Lesson {
  id: string;
  title: string;
  content: string;
  type: "VIDEO" | "TEXT" | "FILE";
  order: number;
}

interface Section {
  id: string;
  title: string;
  order: number;
  lessons: Lesson[];
}

interface Course {
  id: string;
  title: string;
  description?: string | null;
  status: "DRAFT" | "PUBLISHED";
  sections: Section[];
}

export default function CourseBuilderPage() {
  const params = useParams<{ id: string }>();
  const { accessToken, hasHydrated, isAuthorized } = useRequireAuth({ roles: ["INSTRUCTOR"] });
  const [sectionTitle, setSectionTitle] = useState("");

  const courseQuery = useQuery({
    queryKey: ["course-builder", params.id],
    queryFn: () => apiFetch<Course>(`/courses/${params.id}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && params.id && isAuthorized)
  });

  async function addSection(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await apiFetch("/sections", {
      method: "POST",
      token: accessToken ?? undefined,
      body: JSON.stringify({
        title: sectionTitle,
        courseId: params.id
      })
    });
    setSectionTitle("");
    await courseQuery.refetch();
  }

  async function addLesson(sectionId: string) {
    const title = window.prompt("Lesson title");
    if (!title) {
      return;
    }
    const type = window.prompt("Type: VIDEO | TEXT | FILE", "TEXT") ?? "TEXT";
    const content = window.prompt("Lesson content or URL", "") ?? "";

    await apiFetch("/lessons", {
      method: "POST",
      token: accessToken ?? undefined,
      body: JSON.stringify({
        sectionId,
        title,
        type,
        content
      })
    });
    await courseQuery.refetch();
  }

  async function updateSection(sectionId: string, currentTitle: string) {
    const title = window.prompt("New section title", currentTitle);
    if (!title) {
      return;
    }

    await apiFetch(`/sections/${sectionId}`, {
      method: "PATCH",
      token: accessToken ?? undefined,
      body: JSON.stringify({ title })
    });
    await courseQuery.refetch();
  }

  async function deleteSection(sectionId: string) {
    await apiFetch(`/sections/${sectionId}`, {
      method: "DELETE",
      token: accessToken ?? undefined
    });
    await courseQuery.refetch();
  }

  async function updateLesson(lesson: Lesson) {
    const title = window.prompt("New lesson title", lesson.title);
    if (!title) {
      return;
    }
    const content = window.prompt("New lesson content", lesson.content);
    if (content === null) {
      return;
    }
    await apiFetch(`/lessons/${lesson.id}`, {
      method: "PATCH",
      token: accessToken ?? undefined,
      body: JSON.stringify({ title, content })
    });
    await courseQuery.refetch();
  }

  async function deleteLesson(lessonId: string) {
    await apiFetch(`/lessons/${lessonId}`, {
      method: "DELETE",
      token: accessToken ?? undefined
    });
    await courseQuery.refetch();
  }

  return (
    <main className="mx-auto max-w-6xl p-8">
      <BackButton fallbackHref="/instructor/courses" />
      <h1 className="text-2xl font-semibold">Course Builder</h1>

      {courseQuery.data ? (
        <div className="mt-4 rounded-lg bg-white p-4 shadow">
          <p className="text-lg font-medium">{courseQuery.data.title}</p>
          <p className="text-sm text-slate-600">{courseQuery.data.description}</p>
          <p className="mt-2 text-sm">
            Status: <span className="font-medium">{courseQuery.data.status}</span>
          </p>
        </div>
      ) : null}

      <form onSubmit={addSection} className="mt-6 flex gap-2">
        <input
          className="w-full rounded border px-3 py-2"
          placeholder="New section title"
          value={sectionTitle}
          onChange={(event) => setSectionTitle(event.target.value)}
          required
        />
        <button className="rounded bg-slate-900 px-4 py-2 text-white">Add Section</button>
      </form>

      <div className="mt-6 space-y-4">
        {courseQuery.data?.sections?.map((section) => (
          <div key={section.id} className="rounded-xl bg-white p-5 shadow">
            <div className="flex items-center justify-between">
              <p className="font-medium">
                {section.order}. {section.title}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => updateSection(section.id, section.title)}
                  className="rounded border px-3 py-1 text-sm"
                >
                  Edit
                </button>
                <button
                  onClick={() => deleteSection(section.id)}
                  className="rounded border px-3 py-1 text-sm"
                >
                  Delete
                </button>
                <button
                  onClick={() => addLesson(section.id)}
                  className="rounded bg-slate-900 px-3 py-1 text-sm text-white"
                >
                  Add Lesson
                </button>
              </div>
            </div>

            <div className="mt-3 space-y-2">
              {section.lessons.map((lesson) => (
                <div key={lesson.id} className="rounded border p-3">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">
                      {lesson.order}. {lesson.title}
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => updateLesson(lesson)}
                        className="rounded border px-2 py-1 text-xs"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteLesson(lesson.id)}
                        className="rounded border px-2 py-1 text-xs"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-slate-600">Type: {lesson.type}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
