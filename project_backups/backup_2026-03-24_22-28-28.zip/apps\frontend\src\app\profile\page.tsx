"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { ActivityFeed } from "../../components/activity-feed";
import { ContentCard } from "../../components/content-card";
import { PageShell } from "../../components/page-shell";
import { StatusBanner } from "../../components/status-banner";
import { useRequireAuth } from "../../hooks/use-require-auth";
import { apiFetch } from "../../lib/api/client";

interface Profile {
  id: string;
  email: string;
  fullName: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  tenantId: string | null;
  tenant?: {
    id: string;
    name: string;
  } | null;
  createdAt: string;
}

interface InstructorStats {
  studentsCount: number;
  totalRevenue: number;
}

interface StudentInstructorItem {
  id: string;
  createdAt: string;
  instructor: {
    id: string;
    fullName: string;
    email: string;
    tenant?: {
      id: string;
      name: string;
    } | null;
  };
}

interface CourseSummary {
  id: string;
  title: string;
  description?: string | null;
  createdAt?: string;
  status?: "DRAFT" | "PUBLISHED";
}

interface EnrollmentItem {
  id: string;
  courseId: string;
  createdAt: string;
  course: {
    id: string;
    title: string;
    instructor?: {
      id: string;
      fullName: string;
    };
  };
}

interface PaymentItem {
  id: string;
  createdAt: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  course?: {
    id: string;
    title: string;
  };
  user?: {
    id: string;
    fullName: string;
    email: string;
  };
}

export default function ProfilePage() {
  const { accessToken, hasHydrated, user } = useRequireAuth();

  const profileQuery = useQuery({
    queryKey: ["profile", "me"],
    queryFn: () => apiFetch<Profile>("/auth/me", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const instructorStatsQuery = useQuery({
    queryKey: ["instructor", "stats"],
    queryFn: () => apiFetch<InstructorStats>("/instructor/stats", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && profileQuery.data?.role === "INSTRUCTOR")
  });

  const studentInstructorsQuery = useQuery({
    queryKey: ["student-instructors", "profile"],
    queryFn: () => apiFetch<StudentInstructorItem[]>("/student/instructors", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && user?.role === "STUDENT")
  });

  const studentEnrollmentsQuery = useQuery({
    queryKey: ["enrollments", "my-courses", "profile"],
    queryFn: () => apiFetch<EnrollmentItem[]>("/enrollments/my-courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && user?.role === "STUDENT")
  });

  const studentPaymentsQuery = useQuery({
    queryKey: ["payments", "my", "profile"],
    queryFn: () => apiFetch<PaymentItem[]>("/payments/my", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && user?.role === "STUDENT")
  });

  const instructorCoursesQuery = useQuery({
    queryKey: ["courses", "instructor-profile"],
    queryFn: () => apiFetch<CourseSummary[]>("/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && user?.role === "INSTRUCTOR")
  });

  const instructorPaymentsQuery = useQuery({
    queryKey: ["payments", "instructor", "profile"],
    queryFn: () => apiFetch<PaymentItem[]>("/payments/instructor", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && user?.role === "INSTRUCTOR")
  });

  if (!hasHydrated) {
    return <main className="p-8">Loading session...</main>;
  }

  const formattedRevenue = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2
  }).format(instructorStatsQuery.data?.totalRevenue ?? 0);

  const studentActivityItems = useMemo(() => {
    const items = [
      ...(studentInstructorsQuery.data ?? []).map((item) => ({
        id: `join-${item.id}`,
        title: `Joined ${item.instructor.fullName}`,
        description: item.instructor.tenant?.name ?? item.instructor.email,
        timestamp: item.createdAt,
        tone: "neutral" as const
      })),
      ...(studentEnrollmentsQuery.data ?? []).map((item) => ({
        id: `enroll-${item.id}`,
        title: `Enrolled in ${item.course.title}`,
        description: item.course.instructor?.fullName ?? "Course enrollment",
        timestamp: item.createdAt,
        tone: "success" as const
      })),
      ...(studentPaymentsQuery.data ?? []).map((item) => ({
        id: `payment-${item.id}`,
        title: `${item.status.toLowerCase()} payment for ${item.course?.title ?? "course"}`,
        description: `Amount ${item.amount.toFixed(2)}`,
        timestamp: item.createdAt,
        tone: item.status === "APPROVED" ? ("success" as const) : item.status === "REJECTED" ? ("warning" as const) : ("neutral" as const)
      }))
    ];

    return items.sort((left, right) => new Date(right.timestamp).getTime() - new Date(left.timestamp).getTime()).slice(0, 8);
  }, [studentEnrollmentsQuery.data, studentInstructorsQuery.data, studentPaymentsQuery.data]);

  const instructorActivityItems = useMemo(() => {
    const items = [
      ...(instructorCoursesQuery.data ?? []).map((item) => ({
        id: `course-${item.id}`,
        title: `${item.status === "PUBLISHED" ? "Published" : "Updated"} ${item.title}`,
        description: item.description ?? "Course activity",
        timestamp: item.createdAt ?? new Date().toISOString(),
        tone: item.status === "PUBLISHED" ? ("success" as const) : ("neutral" as const)
      })),
      ...(instructorPaymentsQuery.data ?? []).map((item) => ({
        id: `payment-${item.id}`,
        title: `${item.status.toLowerCase()} payment for ${item.course?.title ?? "course"}`,
        description: item.user ? `${item.user.fullName} • ${item.amount.toFixed(2)}` : `Amount ${item.amount.toFixed(2)}`,
        timestamp: item.createdAt,
        tone: item.status === "APPROVED" ? ("success" as const) : item.status === "REJECTED" ? ("warning" as const) : ("neutral" as const)
      }))
    ];

    return items.sort((left, right) => new Date(right.timestamp).getTime() - new Date(left.timestamp).getTime()).slice(0, 8);
  }, [instructorCoursesQuery.data, instructorPaymentsQuery.data]);

  return (
    <PageShell title="Profile" description="Account details and instructor performance overview." backHref="/dashboard" maxWidthClassName="max-w-3xl">
      {profileQuery.isLoading ? <StatusBanner>Loading profile...</StatusBanner> : null}
      {profileQuery.isError ? <StatusBanner variant="error">Failed to load profile.</StatusBanner> : null}
      {profileQuery.data ? (
        <div className="mt-6 space-y-4">
          <div className="grid gap-4 md:grid-cols-[minmax(0,2fr)_minmax(260px,1fr)]">
          <ContentCard className="space-y-2 p-6">
            <p>
              <span className="font-medium">Name:</span> {profileQuery.data.fullName}
            </p>
            <p>
              <span className="font-medium">Email:</span> {profileQuery.data.email}
            </p>
            <p>
              <span className="font-medium">Role:</span> {profileQuery.data.role}
            </p>
            <p>
              <span className="font-medium">Tenant:</span>{" "}
              {profileQuery.data.tenant?.name ?? profileQuery.data.tenantId ?? "Not assigned"}
            </p>
          </ContentCard>

          {profileQuery.data.role === "INSTRUCTOR" ? (
            <div className="rounded-2xl border border-slate-200 bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-800 p-6 text-white shadow-sm">
              <p className="text-xs uppercase tracking-[0.2em] text-slate-300">Instructor Stats</p>
              {instructorStatsQuery.isLoading ? (
                <p className="mt-4 text-sm text-slate-200">Loading instructor stats...</p>
              ) : instructorStatsQuery.isError ? (
                <p className="mt-4 text-sm text-rose-200">Failed to load instructor stats.</p>
              ) : (
                <div className="mt-4 space-y-4">
                  <div className="rounded-2xl bg-white/10 p-4 backdrop-blur-sm">
                    <p className="text-xs uppercase tracking-[0.16em] text-slate-300">Students</p>
                    <p className="mt-2 text-4xl font-semibold leading-none">
                      {instructorStatsQuery.data?.studentsCount ?? 0}
                    </p>
                    <p className="mt-3 text-sm text-slate-200">
                      Distinct students linked through tenant joining or course enrollment.
                    </p>
                  </div>

                  <div className="rounded-2xl bg-emerald-400/15 p-4 backdrop-blur-sm">
                    <p className="text-xs uppercase tracking-[0.16em] text-emerald-100">Total Revenue</p>
                    <p className="mt-2 text-3xl font-semibold leading-none">{formattedRevenue}</p>
                    <p className="mt-3 text-sm text-emerald-50">
                      Sum of approved manual payments for courses you own.
                    </p>
                  </div>
                </div>
              )}
            </div>
          ) : null}
          </div>

          {profileQuery.data.role === "STUDENT" ? (
            <ActivityFeed
              title="Recent Activity"
              description="Your latest instructor joins, enrollments, and payment updates."
              items={studentActivityItems}
              emptyMessage="No recent activity yet."
            />
          ) : null}

          {profileQuery.data.role === "INSTRUCTOR" ? (
            <ActivityFeed
              title="Recent Activity"
              description="Latest course changes and student payment activity for your workspace."
              items={instructorActivityItems}
              emptyMessage="No recent instructor activity yet."
            />
          ) : null}
        </div>
      ) : null}
    </PageShell>
  );
}
