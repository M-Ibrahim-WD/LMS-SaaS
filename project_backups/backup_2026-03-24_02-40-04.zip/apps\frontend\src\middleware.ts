import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const protectedPaths = ["/dashboard", "/profile", "/join-tenant", "/instructor", "/courses", "/my-courses"];
const publicAuthPaths = ["/login", "/register"];

export function middleware(request: NextRequest) {
  const token = request.cookies.get("access_token")?.value;
  const pathname = request.nextUrl.pathname;

  const isProtected = protectedPaths.some((path) => pathname.startsWith(path));
  const isPublicAuth = publicAuthPaths.some((path) => pathname.startsWith(path));

  if (process.env.NODE_ENV !== "production") {
    console.info("[middleware]", { pathname, hasToken: Boolean(token), isProtected, isPublicAuth });
  }

  if (isProtected && !token) {
    const loginUrl = new URL("/login", request.url);
    return NextResponse.redirect(loginUrl);
  }

  if (isPublicAuth && token) {
    const dashboardUrl = new URL("/dashboard", request.url);
    return NextResponse.redirect(dashboardUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/profile/:path*",
    "/join-tenant",
    "/instructor/:path*",
    "/courses/:path*",
    "/my-courses/:path*",
    "/login",
    "/register"
  ]
};
