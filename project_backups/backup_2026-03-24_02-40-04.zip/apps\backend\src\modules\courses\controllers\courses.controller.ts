import { Body, Controller, Get, Param, Patch, Post, UseGuards } from "@nestjs/common";
import { CurrentUser } from "../../../shared/decorators/current-user.decorator";
import { RequireTenant } from "../../../shared/decorators/require-tenant.decorator";
import { Roles } from "../../../shared/decorators/roles.decorator";
import { TenantContextGuard } from "../../../shared/guards/tenant-context.guard";
import { RolesGuard } from "../../../shared/guards/roles.guard";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { JwtAuthGuard } from "../../auth/guards/jwt-auth.guard";
import { CreateCourseDto } from "../dto/create-course.dto";
import { UpdateCourseStatusDto } from "../dto/update-course-status.dto";
import { UpdateCourseDto } from "../dto/update-course.dto";
import { CoursesService } from "../services/courses.service";

@Controller("courses")
@UseGuards(JwtAuthGuard, TenantContextGuard, RolesGuard)
@RequireTenant()
export class CoursesController {
  constructor(private readonly coursesService: CoursesService) {}

  @Roles("INSTRUCTOR")
  @Post()
  create(@CurrentUser() user: JwtPayload, @Body() dto: CreateCourseDto) {
    return this.coursesService.create(user, dto);
  }

  @Roles("INSTRUCTOR")
  @Patch(":id")
  update(@CurrentUser() user: JwtPayload, @Param("id") id: string, @Body() dto: UpdateCourseDto) {
    return this.coursesService.update(user, id, dto);
  }

  @Roles("INSTRUCTOR")
  @Patch(":id/status")
  updateStatus(
    @CurrentUser() user: JwtPayload,
    @Param("id") id: string,
    @Body() dto: UpdateCourseStatusDto
  ) {
    return this.coursesService.updateStatus(user, id, dto);
  }

  @Get()
  getAll(@CurrentUser() user: JwtPayload) {
    return this.coursesService.getAllByTenant(user);
  }

  @Get(":id")
  getOne(@CurrentUser() user: JwtPayload, @Param("id") id: string) {
    return this.coursesService.getOne(user, id);
  }
}

