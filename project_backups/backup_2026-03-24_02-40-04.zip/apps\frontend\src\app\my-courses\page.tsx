"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { apiFetch } from "../../lib/api/client";
import { BackButton } from "../../components/back-button";
import { ContentCard } from "../../components/content-card";
import { EmptyState } from "../../components/empty-state";
import { useAuthStore } from "../../store/auth.store";

interface Course {
  id: string;
  title: string;
  description?: string | null;
  status: "DRAFT" | "PUBLISHED";
  instructor?: {
    id: string;
    fullName: string;
  };
}

interface Enrollment {
  id: string;
  courseId: string;
  createdAt: string;
  course: Course;
}

export default function MyCoursesPage() {
  const router = useRouter();
  const accessToken = useAuthStore((state) => state.accessToken);
  const user = useAuthStore((state) => state.user);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);
  const isStudent = user?.role === "STUDENT";

  useEffect(() => {
    if (!hasHydrated) {
      return;
    }

    if (!accessToken) {
      router.replace("/login");
      return;
    }

  }, [accessToken, hasHydrated, router]);

  const myCoursesQuery = useQuery({
    queryKey: ["enrollments", "my-courses"],
    queryFn: () => apiFetch<Enrollment[]>("/enrollments/my-courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && isStudent)
  });

  if (!hasHydrated) {
    return <main className="p-8">Loading session...</main>;
  }

  return (
    <main className="mx-auto max-w-5xl p-8">
      <BackButton fallbackHref="/dashboard" />
      <h1 className="text-2xl font-semibold">My Courses</h1>
      <p className="mt-2 text-sm text-slate-600">Courses you enrolled in will appear here.</p>

      {user && !isStudent ? (
        <div className="mt-6">
          <EmptyState
            title="Student enrollments only"
            description="This page is reserved for student course enrollments."
            actionHref="/courses"
            actionLabel="Browse Courses"
          />
        </div>
      ) : null}

      {myCoursesQuery.isLoading ? <p className="mt-6">Loading courses...</p> : null}
      {myCoursesQuery.isError ? (
        <p className="mt-6 text-red-600">Failed to load your courses. Please try again.</p>
      ) : null}

      {myCoursesQuery.data && myCoursesQuery.data.length === 0 ? (
        <div className="mt-6">
          <EmptyState
            title="No enrolled courses yet"
            description="Enroll in a course to start learning here."
            actionHref="/courses"
            actionLabel="Browse Courses"
          />
        </div>
      ) : null}

      <div className="mt-6 grid gap-3">
        {myCoursesQuery.data?.map((enrollment) => (
          <Link key={enrollment.id} href={`/courses/${enrollment.course.id}`}>
            <ContentCard className="transition hover:border-slate-300 hover:shadow-md">
            <p className="font-medium">{enrollment.course.title}</p>
            <p className="text-sm text-slate-600">{enrollment.course.description}</p>
            {enrollment.course.instructor ? (
              <p className="mt-1 text-xs text-slate-500">{enrollment.course.instructor.fullName}</p>
            ) : null}
            </ContentCard>
          </Link>
        ))}
      </div>
    </main>
  );
}
