import { Type } from "class-transformer";
import {
  IsBoolean,
  IsNumber,
  IsOptional,
  IsString,
  Min,
  MinLength,
  ValidateIf
} from "class-validator";

export class UpdateCourseDto {
  @IsOptional()
  @IsString()
  @MinLength(3)
  title?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @Type(() => Boolean)
  @IsOptional()
  @IsBoolean()
  isPaid?: boolean;

  @ValidateIf((obj: UpdateCourseDto) => obj.isPaid === true || obj.price !== undefined)
  @Type(() => Number)
  @IsNumber()
  @Min(0.01)
  price?: number;
}
