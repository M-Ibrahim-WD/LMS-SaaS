import { Type } from "class-transformer";
import {
  IsBoolean,
  IsNumber,
  IsOptional,
  IsString,
  Min,
  MinLength,
  ValidateIf
} from "class-validator";

export class CreateCourseDto {
  @IsString()
  @MinLength(3)
  title!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @Type(() => Boolean)
  @IsOptional()
  @IsBoolean()
  isPaid?: boolean;

  @ValidateIf((obj: CreateCourseDto) => Boolean(obj.isPaid))
  @Type(() => Number)
  @IsNumber()
  @Min(0.01)
  price?: number;
}
