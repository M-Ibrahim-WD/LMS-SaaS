"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useState } from "react";
import { apiFetch } from "../../lib/api/client";
import { clearAuthCookie } from "../../lib/auth/session";
import {
  PAYMENT_METHOD_OPTIONS,
  type PaymentMethodType,
  placeholderForPaymentType,
  validatePaymentMethodDetails
} from "../../lib/payments/payment-methods";
import { BackButton } from "../../components/back-button";
import { PaymentProofActions } from "../../components/payment-proof-actions";
import { useAuthStore } from "../../store/auth.store";

interface Profile {
  id: string;
  email: string;
  fullName: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  tenantId: string | null;
  tenant?: {
    id: string;
    name: string;
  } | null;
  createdAt: string;
}

interface InviteCodeResponse {
  inviteCode: string;
}

interface PaymentMethod {
  id: string;
  type: PaymentMethodType;
  category: "MANUAL" | "ONLINE";
  label: string;
  details: string;
  isActive: boolean;
}

interface InstructorPayment {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  proof: string;
  proofPreviewUrl?: string;
  proofDownloadUrl?: string;
  proofContentType?: string | null;
  proofFileName?: string | null;
  course: {
    id: string;
    title: string;
    price?: number | null;
  };
  user: {
    id: string;
    fullName: string;
    email: string;
  };
  method: {
    id: string;
    label: string;
    type: PaymentMethodType;
  };
}

export default function DashboardPage() {
  const router = useRouter();
  const accessToken = useAuthStore((state) => state.accessToken);
  const user = useAuthStore((state) => state.user);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);
  const clearSession = useAuthStore((state) => state.clearSession);
  const [methodType, setMethodType] = useState<PaymentMethodType>("INSTAPAY");
  const [methodLabel, setMethodLabel] = useState("Instapay");
  const [methodDetails, setMethodDetails] = useState("");
  const [methodValidationError, setMethodValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (!hasHydrated) {
      return;
    }

    if (!accessToken) {
      router.replace("/login");
    }
    if (user && !user.tenantId) {
      router.replace("/join-tenant");
    }
  }, [accessToken, hasHydrated, router, user]);

  const profileQuery = useQuery({
    queryKey: ["me"],
    queryFn: () => apiFetch<Profile>("/auth/me", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken)
  });

  const inviteCodeQuery = useQuery({
    queryKey: ["tenant-invite-code"],
    queryFn: () =>
      apiFetch<InviteCodeResponse>("/tenants/invite-code", {
        token: accessToken ?? undefined
      }),
    enabled: Boolean(accessToken && user?.role === "INSTRUCTOR" && user?.tenantId)
  });

  const paymentMethodsQuery = useQuery({
    queryKey: ["payment-methods", "my"],
    queryFn: () => apiFetch<PaymentMethod[]>("/payment-methods/my", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "INSTRUCTOR" && user?.tenantId)
  });

  const instructorPaymentsQuery = useQuery({
    queryKey: ["payments", "instructor"],
    queryFn: () =>
      apiFetch<InstructorPayment[]>("/payments/instructor", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "INSTRUCTOR" && user?.tenantId)
  });

  const createMethodMutation = useMutation({
    mutationFn: () =>
      apiFetch<PaymentMethod>("/payment-methods", {
        method: "POST",
        token: accessToken ?? undefined,
        body: JSON.stringify({
          type: methodType,
          label: methodLabel,
          details: methodDetails
        })
      }),
    onSuccess: async () => {
      setMethodDetails("");
      setMethodValidationError(null);
      await paymentMethodsQuery.refetch();
    },
    onError: (error) => {
      setMethodValidationError(
        error instanceof Error ? error.message.replace(/^API request failed:\s*\d+\s*:?/i, "").trim() : "Failed to add method."
      );
    }
  });

  const approveMutation = useMutation({
    mutationFn: (paymentId: string) =>
      apiFetch(`/payments/${paymentId}/approve`, {
        method: "PATCH",
        token: accessToken ?? undefined
      }),
    onSuccess: async () => {
      await instructorPaymentsQuery.refetch();
    }
  });

  const rejectMutation = useMutation({
    mutationFn: (paymentId: string) =>
      apiFetch(`/payments/${paymentId}/reject`, {
        method: "PATCH",
        token: accessToken ?? undefined
      }),
    onSuccess: async () => {
      await instructorPaymentsQuery.refetch();
    }
  });

  function onLogout() {
    clearSession();
    clearAuthCookie();
    router.push("/login");
  }

  async function onCopyInviteCode() {
    if (!inviteCodeQuery.data?.inviteCode) {
      return;
    }

    await navigator.clipboard.writeText(inviteCodeQuery.data.inviteCode);
  }

  async function onCreateMethod(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const detailsError = validatePaymentMethodDetails(methodType, methodDetails);
    if (detailsError) {
      setMethodValidationError(detailsError);
      return;
    }

    setMethodValidationError(null);
    await createMethodMutation.mutateAsync();
  }

  if (!hasHydrated) {
    return <main className="p-8">Loading session...</main>;
  }

  if (!accessToken) {
    return <main className="p-8">Redirecting...</main>;
  }

  return (
    <main className="mx-auto max-w-4xl p-8">
      <div className="rounded-2xl bg-white p-6 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton fallbackHref="/courses" />
            <h1 className="text-2xl font-semibold">Dashboard</h1>
          </div>
          <div className="flex items-center gap-2">
            <a href="/profile" className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-700">
              Profile
            </a>
            <button onClick={onLogout} className="rounded-lg bg-slate-900 px-4 py-2 text-white">
              Logout
            </button>
          </div>
        </div>

        {profileQuery.isLoading ? <p className="mt-4">Loading profile...</p> : null}
        {profileQuery.isError ? (
          <p className="mt-4 text-red-600">Failed to load profile. Please login again.</p>
        ) : null}

        {profileQuery.data ? (
          <div className="mt-6 space-y-2 text-slate-700">
            <p>
              <span className="font-medium">Name:</span> {profileQuery.data.fullName}
            </p>
            <p>
              <span className="font-medium">Email:</span> {profileQuery.data.email}
            </p>
            <p>
              <span className="font-medium">Role:</span> {profileQuery.data.role}
            </p>
            <p>
              <span className="font-medium">Tenant:</span>{" "}
              {profileQuery.data.tenant?.name ?? profileQuery.data.tenantId}
            </p>

            {profileQuery.data.role === "INSTRUCTOR" ? (
              <div className="mt-4 space-y-4">
                <div className="rounded-lg border border-slate-200 p-4">
                  <div className="mb-3 flex gap-2">
                    <a href="/instructor/courses" className="rounded bg-slate-900 px-3 py-2 text-sm text-white">
                      Create & Manage Courses
                    </a>
                    <a href="/courses" className="rounded border border-slate-300 px-3 py-2 text-sm">
                      View Courses
                    </a>
                  </div>
                  <p className="text-sm font-medium text-slate-600">Your Invite Code</p>
                  <div className="mt-2 flex items-center justify-between gap-3">
                    <code className="rounded bg-slate-100 px-3 py-2 text-sm">
                      {inviteCodeQuery.data?.inviteCode ?? "Loading..."}
                    </code>
                    <button
                      type="button"
                      onClick={onCopyInviteCode}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    >
                      Copy
                    </button>
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 p-4">
                  <p className="text-sm font-semibold text-slate-700">Payment Methods</p>
                  <form onSubmit={onCreateMethod} className="mt-3 space-y-3">
                    <select
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
                      value={methodType}
                      onChange={(event) => {
                        const nextType = event.target.value as PaymentMethodType;
                        setMethodType(nextType);
                        setMethodValidationError(null);
                        const nextLabel = PAYMENT_METHOD_OPTIONS.find((item) => item.value === nextType)?.label ?? nextType;
                        setMethodLabel(nextLabel.replace(" (Future)", ""));
                      }}
                    >
                      {PAYMENT_METHOD_OPTIONS.map((item) => (
                        <option key={item.value} value={item.value}>
                          {item.label}
                        </option>
                      ))}
                    </select>
                    <input
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Label (e.g. Vodafone Wallet)"
                      value={methodLabel}
                      onChange={(event) => setMethodLabel(event.target.value)}
                      required
                    />
                    <textarea
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
                      placeholder={placeholderForPaymentType(methodType)}
                      value={methodDetails}
                      onChange={(event) => {
                        setMethodDetails(event.target.value);
                        if (methodValidationError) {
                          setMethodValidationError(null);
                        }
                      }}
                    />
                    {methodValidationError ? (
                      <p className="text-xs text-red-600">{methodValidationError}</p>
                    ) : null}
                    <button
                      type="submit"
                      disabled={createMethodMutation.isPending}
                      className="rounded bg-slate-900 px-3 py-2 text-sm text-white disabled:opacity-60"
                    >
                      {createMethodMutation.isPending ? "Saving..." : "Add Method"}
                    </button>
                  </form>

                  <div className="mt-4 space-y-2">
                    {paymentMethodsQuery.data?.map((method) => (
                      <div key={method.id} className="rounded border border-slate-200 p-3 text-sm">
                        <p className="font-medium">{method.label}</p>
                        <p className="text-slate-600">
                          {method.type} • {method.category}
                        </p>
                        <p className="mt-1 text-slate-700">{method.details || "No details"}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 p-4">
                  <p className="text-sm font-semibold text-slate-700">Student Payments</p>
                  <div className="mt-3 space-y-2">
                    {instructorPaymentsQuery.data?.length ? (
                      instructorPaymentsQuery.data.map((payment) => (
                        <div key={payment.id} className="rounded border border-slate-200 p-3 text-sm">
                          <p className="font-medium">{payment.course.title}</p>
                          <p className="text-slate-600">
                            {payment.user.fullName} ({payment.user.email})
                          </p>
                          <p className="text-slate-600">
                            {payment.method.label} • {payment.method.type}
                          </p>
                          <p className="text-slate-700">
                            Amount: {payment.amount.toFixed(2)} • Status: {payment.status}
                          </p>
                          <PaymentProofActions
                            paymentId={payment.id}
                            accessToken={accessToken ?? ""}
                            proofContentType={payment.proofContentType}
                            proofFileName={payment.proofFileName}
                          />
                          {payment.status === "PENDING" ? (
                            <div className="mt-2 flex gap-2">
                              <button
                                type="button"
                                onClick={() => approveMutation.mutate(payment.id)}
                                className="rounded border border-emerald-300 px-3 py-1 text-xs text-emerald-700"
                              >
                                Approve
                              </button>
                              <button
                                type="button"
                                onClick={() => rejectMutation.mutate(payment.id)}
                                className="rounded border border-red-300 px-3 py-1 text-xs text-red-700"
                              >
                                Reject
                              </button>
                            </div>
                          ) : null}
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-500">No payment submissions yet.</p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-4 flex gap-2">
                <a href="/my-courses" className="rounded border border-slate-300 px-3 py-2 text-sm">
                  My Courses
                </a>
                <a href="/courses" className="rounded bg-slate-900 px-3 py-2 text-sm text-white">
                  Browse Courses
                </a>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </main>
  );
}
