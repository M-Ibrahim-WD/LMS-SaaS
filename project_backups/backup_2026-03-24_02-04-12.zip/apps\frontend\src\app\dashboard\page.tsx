"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { apiFetch } from "../../lib/api/client";
import { clearAuthCookie } from "../../lib/auth/session";
import {
  PAYMENT_METHOD_OPTIONS,
  type PaymentMethodType,
  placeholderForPaymentType,
  validatePaymentMethodDetails
} from "../../lib/payments/payment-methods";
import { BackButton } from "../../components/back-button";
import { PaymentProofActions } from "../../components/payment-proof-actions";
import { useAuthStore } from "../../store/auth.store";

interface Profile {
  id: string;
  email: string;
  fullName: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  tenantId: string | null;
  tenant?: {
    id: string;
    name: string;
  } | null;
  createdAt: string;
}

interface InviteCodeResponse {
  inviteCode: string;
}

interface StudentInstructorItem {
  id: string;
  createdAt: string;
  instructor: {
    id: string;
    fullName: string;
    email: string;
    tenant?: {
      id: string;
      name: string;
      inviteCode: string;
    } | null;
  };
}

interface StudentCourse {
  id: string;
  title: string;
  description?: string | null;
  isPaid: boolean;
  price?: number | null;
  status: "DRAFT" | "PUBLISHED";
  instructor?: {
    id: string;
    fullName: string;
  };
}

interface EnrolledCourse {
  id: string;
  courseId: string;
  createdAt: string;
  course: StudentCourse;
}

type StudentTab = "ALL" | "MY" | "INSTRUCTOR";
type CourseFilter = "ALL" | "FREE" | "PAID";

interface PaymentMethod {
  id: string;
  type: PaymentMethodType;
  category: "MANUAL" | "ONLINE";
  label: string;
  details: string;
  isActive: boolean;
}

interface InstructorPayment {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  proof: string;
  proofPreviewUrl?: string;
  proofDownloadUrl?: string;
  proofContentType?: string | null;
  proofFileName?: string | null;
  course: {
    id: string;
    title: string;
    price?: number | null;
  };
  user: {
    id: string;
    fullName: string;
    email: string;
  };
  method: {
    id: string;
    label: string;
    type: PaymentMethodType;
  };
}

export default function DashboardPage() {
  const router = useRouter();
  const accessToken = useAuthStore((state) => state.accessToken);
  const user = useAuthStore((state) => state.user);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);
  const clearSession = useAuthStore((state) => state.clearSession);
  const queryClient = useQueryClient();
  const [methodType, setMethodType] = useState<PaymentMethodType>("INSTAPAY");
  const [methodLabel, setMethodLabel] = useState("Instapay");
  const [methodDetails, setMethodDetails] = useState("");
  const [methodValidationError, setMethodValidationError] = useState<string | null>(null);
  const [deleteMethodError, setDeleteMethodError] = useState<string | null>(null);
  const [studentInviteCode, setStudentInviteCode] = useState("");
  const [studentJoinError, setStudentJoinError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<StudentTab>("ALL");
  const [filterType, setFilterType] = useState<CourseFilter>("ALL");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (!hasHydrated) {
      return;
    }

    if (!accessToken) {
      router.replace("/login");
      return;
    }
  }, [accessToken, hasHydrated, router]);

  const profileQuery = useQuery({
    queryKey: ["me"],
    queryFn: () => apiFetch<Profile>("/auth/me", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken)
  });

  const inviteCodeQuery = useQuery({
    queryKey: ["tenant-invite-code"],
    queryFn: () =>
      apiFetch<InviteCodeResponse>("/tenants/invite-code", {
        token: accessToken ?? undefined
      }),
    enabled: Boolean(accessToken && user?.role === "INSTRUCTOR" && user?.tenantId)
  });

  const paymentMethodsQuery = useQuery({
    queryKey: ["payment-methods", "my"],
    queryFn: () => apiFetch<PaymentMethod[]>("/payment-methods/my", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "INSTRUCTOR" && user?.tenantId)
  });

  const instructorPaymentsQuery = useQuery({
    queryKey: ["payments", "instructor"],
    queryFn: () =>
      apiFetch<InstructorPayment[]>("/payments/instructor", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "INSTRUCTOR" && user?.tenantId)
  });

  const studentInstructorsQuery = useQuery({
    queryKey: ["student-instructors"],
    queryFn: () =>
      apiFetch<StudentInstructorItem[]>("/student/instructors", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "STUDENT")
  });

  const studentCoursesQuery = useQuery({
    queryKey: ["courses", "student-dashboard"],
    queryFn: () => apiFetch<StudentCourse[]>("/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "STUDENT")
  });

  const studentMyCoursesQuery = useQuery({
    queryKey: ["enrollments", "my-courses", "student-dashboard"],
    queryFn: () => apiFetch<EnrolledCourse[]>("/enrollments/my-courses", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken && user?.role === "STUDENT")
  });

  const createMethodMutation = useMutation({
    mutationFn: () =>
      apiFetch<PaymentMethod>("/payment-methods", {
        method: "POST",
        token: accessToken ?? undefined,
        body: JSON.stringify({
          type: methodType,
          label: methodLabel,
          details: methodDetails
        })
      }),
    onSuccess: async () => {
      setMethodDetails("");
      setMethodValidationError(null);
      await paymentMethodsQuery.refetch();
    },
    onError: (error) => {
      setMethodValidationError(
        error instanceof Error
          ? error.message.replace(/^API request failed:\s*\d+\s*:?/i, "").trim()
          : "Failed to add method."
      );
    }
  });

  const approveMutation = useMutation({
    mutationFn: (paymentId: string) =>
      apiFetch(`/payments/${paymentId}/approve`, {
        method: "PATCH",
        token: accessToken ?? undefined
      }),
    onSuccess: async () => {
      await instructorPaymentsQuery.refetch();
    }
  });

  const rejectMutation = useMutation({
    mutationFn: (paymentId: string) =>
      apiFetch(`/payments/${paymentId}/reject`, {
        method: "PATCH",
        token: accessToken ?? undefined
      }),
    onSuccess: async () => {
      await instructorPaymentsQuery.refetch();
    }
  });

  const deleteMethodMutation = useMutation({
    mutationFn: (methodId: string) =>
      apiFetch<PaymentMethod>(`/payment-methods/${methodId}`, {
        method: "DELETE",
        token: accessToken ?? undefined
      }),
    onSuccess: async () => {
      setDeleteMethodError(null);
      await paymentMethodsQuery.refetch();
    },
    onError: (error) => {
      setDeleteMethodError(error instanceof Error ? error.message : "Failed to delete payment method.");
    }
  });

  const joinInstructorMutation = useMutation({
    mutationFn: () =>
      apiFetch("/student/instructors/join", {
        method: "POST",
        token: accessToken ?? undefined,
        body: JSON.stringify({
          inviteCode: studentInviteCode
        })
      }),
    onSuccess: async () => {
      setStudentInviteCode("");
      setStudentJoinError(null);
      await Promise.all([
        studentInstructorsQuery.refetch(),
        studentCoursesQuery.refetch(),
        studentMyCoursesQuery.refetch(),
        queryClient.invalidateQueries({ queryKey: ["courses"] })
      ]);
    },
    onError: (error) => {
      setStudentJoinError(error instanceof Error ? error.message : "Unable to join instructor.");
    }
  });

  function onLogout() {
    clearSession();
    clearAuthCookie();
    router.push("/login");
  }

  async function onCopyInviteCode() {
    if (!inviteCodeQuery.data?.inviteCode) {
      return;
    }

    await navigator.clipboard.writeText(inviteCodeQuery.data.inviteCode);
  }

  async function onCreateMethod(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const detailsError = validatePaymentMethodDetails(methodType, methodDetails);
    if (detailsError) {
      setMethodValidationError(detailsError);
      return;
    }

    const normalizedDetails = methodDetails.trim();
    const duplicateMethod = paymentMethodsQuery.data?.some(
      (method) => method.type === methodType && method.details.trim() === normalizedDetails
    );

    if (duplicateMethod) {
      setMethodValidationError("This account is already added for this payment method");
      return;
    }

    setMethodValidationError(null);
    await createMethodMutation.mutateAsync();
  }

  async function onDeleteMethod(methodId: string) {
    const confirmed = window.confirm("Delete this payment method? It will no longer be available for new payments.");
    if (!confirmed) {
      return;
    }

    setDeleteMethodError(null);
    await deleteMethodMutation.mutateAsync(methodId);
  }

  async function onJoinInstructor(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const normalizedInviteCode = studentInviteCode.trim().toUpperCase();
    if (!normalizedInviteCode) {
      setStudentJoinError("Invite code is required.");
      return;
    }

    const duplicateInstructor = studentInstructorsQuery.data?.some(
      (item) => item.instructor.tenant?.inviteCode === normalizedInviteCode
    );

    if (duplicateInstructor) {
      setStudentJoinError("Already joined this instructor");
      return;
    }

    setStudentInviteCode(normalizedInviteCode);
    setStudentJoinError(null);
    await joinInstructorMutation.mutateAsync();
  }

  const studentCourses = useMemo(() => {
    const enrolledIds = new Set((studentMyCoursesQuery.data ?? []).map((item) => item.courseId));

    return (studentCoursesQuery.data ?? []).map((course) => ({
      ...course,
      description: course.description ?? "",
      instructorId: course.instructor?.id ?? "",
      instructorName: course.instructor?.fullName ?? "Unknown Instructor",
      isEnrolled: enrolledIds.has(course.id)
    }));
  }, [studentCoursesQuery.data, studentMyCoursesQuery.data]);

  const filteredStudentCourses = useMemo(() => {
    const normalizedQuery = searchQuery.trim().toLowerCase();

    return studentCourses
      .filter((course) => {
        if (activeTab === "MY") {
          return course.isEnrolled;
        }
        return true;
      })
      .filter((course) => {
        if (filterType === "FREE") {
          return !course.isPaid;
        }
        if (filterType === "PAID") {
          return course.isPaid;
        }
        return true;
      })
      .filter((course) => {
        if (!normalizedQuery) {
          return true;
        }

        return (
          course.title.toLowerCase().includes(normalizedQuery) ||
          course.description.toLowerCase().includes(normalizedQuery)
        );
      });
  }, [activeTab, filterType, searchQuery, studentCourses]);

  const groupedCoursesByInstructor = useMemo(() => {
    return filteredStudentCourses.reduce<Record<string, typeof filteredStudentCourses>>((groups, course) => {
      const key = course.instructorName;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(course);
      return groups;
    }, {});
  }, [filteredStudentCourses]);

  const studentEmptyStateMessage = useMemo(() => {
    if (searchQuery.trim() && filteredStudentCourses.length === 0) {
      return "No results for your search";
    }

    if (activeTab === "MY" && filteredStudentCourses.length === 0) {
      return "You are not enrolled in any courses yet";
    }

    return "No courses found";
  }, [activeTab, filteredStudentCourses.length, searchQuery]);

  if (!hasHydrated) {
    return <main className="p-8">Loading session...</main>;
  }

  if (!accessToken) {
    return <main className="p-8">Redirecting...</main>;
  }

  return (
    <main className="mx-auto max-w-4xl p-8">
      <div className="rounded-2xl bg-white p-6 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton fallbackHref="/courses" />
            <h1 className="text-2xl font-semibold">Dashboard</h1>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/profile"
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-700"
            >
              Profile
            </Link>
            <button onClick={onLogout} className="rounded-lg bg-slate-900 px-4 py-2 text-white">
              Logout
            </button>
          </div>
        </div>

        {profileQuery.isLoading ? <p className="mt-4">Loading profile...</p> : null}
        {profileQuery.isError ? (
          <p className="mt-4 text-red-600">Failed to load profile. Please login again.</p>
        ) : null}

        {profileQuery.data ? (
          <div className="mt-6 space-y-2 text-slate-700">
            <p>
              <span className="font-medium">Name:</span> {profileQuery.data.fullName}
            </p>
            <p>
              <span className="font-medium">Email:</span> {profileQuery.data.email}
            </p>
            <p>
              <span className="font-medium">Role:</span> {profileQuery.data.role}
            </p>
            <p>
              <span className="font-medium">Tenant:</span>{" "}
              {profileQuery.data.tenant?.name ?? profileQuery.data.tenantId ?? "Not assigned"}
            </p>

            {profileQuery.data.role === "INSTRUCTOR" ? (
              <div className="mt-4 space-y-4">
                <div className="rounded-lg border border-slate-200 p-4">
                  <div className="mb-3 flex gap-2">
                    <Link
                      href="/instructor/courses"
                      className="rounded bg-slate-900 px-3 py-2 text-sm text-white"
                    >
                      Create & Manage Courses
                    </Link>
                    <Link href="/courses" className="rounded border border-slate-300 px-3 py-2 text-sm">
                      View Courses
                    </Link>
                  </div>
                  <p className="text-sm font-medium text-slate-600">Your Invite Code</p>
                  <div className="mt-2 flex items-center justify-between gap-3">
                    <code className="rounded bg-slate-100 px-3 py-2 text-sm">
                      {inviteCodeQuery.data?.inviteCode ?? "Loading..."}
                    </code>
                    <button
                      type="button"
                      onClick={onCopyInviteCode}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    >
                      Copy
                    </button>
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 p-4">
                  <p className="text-sm font-semibold text-slate-700">Payment Methods</p>
                  <form onSubmit={onCreateMethod} className="mt-3 space-y-3">
                    <select
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
                      value={methodType}
                      onChange={(event) => {
                        const nextType = event.target.value as PaymentMethodType;
                        setMethodType(nextType);
                        setMethodValidationError(null);
                        const nextLabel =
                          PAYMENT_METHOD_OPTIONS.find((item) => item.value === nextType)?.label ?? nextType;
                        setMethodLabel(nextLabel.replace(" (Future)", ""));
                      }}
                    >
                      {PAYMENT_METHOD_OPTIONS.map((item) => (
                        <option key={item.value} value={item.value}>
                          {item.label}
                        </option>
                      ))}
                    </select>
                    <input
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Label (e.g. Vodafone Wallet)"
                      value={methodLabel}
                      onChange={(event) => setMethodLabel(event.target.value)}
                      required
                    />
                    <textarea
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
                      placeholder={placeholderForPaymentType(methodType)}
                      value={methodDetails}
                      onChange={(event) => {
                        setMethodDetails(event.target.value);
                        if (methodValidationError) {
                          setMethodValidationError(null);
                        }
                      }}
                    />
                    {methodValidationError ? (
                      <p className="text-xs text-red-600">{methodValidationError}</p>
                    ) : null}
                    <button
                      type="submit"
                      disabled={createMethodMutation.isPending}
                      className="rounded bg-slate-900 px-3 py-2 text-sm text-white disabled:opacity-60"
                    >
                      {createMethodMutation.isPending ? "Saving..." : "Add Method"}
                    </button>
                  </form>

                  {deleteMethodError ? <p className="mt-3 text-xs text-red-600">{deleteMethodError}</p> : null}

                  <div className="mt-4 space-y-2">
                    {paymentMethodsQuery.data?.length ? (
                      paymentMethodsQuery.data.map((method) => (
                        <div
                          key={method.id}
                          className="flex items-start justify-between gap-3 rounded border border-slate-200 p-3 text-sm"
                        >
                          <div className="min-w-0 flex-1">
                            <p className="font-medium">{method.label}</p>
                            <p className="text-slate-600">
                              {method.type} • {method.category}
                            </p>
                            <p className="mt-1 text-slate-700">{method.details || "No details"}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => void onDeleteMethod(method.id)}
                            disabled={deleteMethodMutation.isPending}
                            className="rounded border border-red-200 px-2 py-1 text-xs font-medium text-red-600 disabled:opacity-60"
                            aria-label={`Delete ${method.label}`}
                          >
                            X
                          </button>
                        </div>
                      ))
                    ) : (
                      <div className="rounded border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-500">
                        No payment methods yet. Add one to start receiving manual course payments.
                      </div>
                    )}
                  </div>
                </div>

                <div className="rounded-lg border border-slate-200 p-4">
                  <p className="text-sm font-semibold text-slate-700">Student Payments</p>
                  <div className="mt-3 space-y-2">
                    {instructorPaymentsQuery.data?.length ? (
                      instructorPaymentsQuery.data.map((payment) => (
                        <div key={payment.id} className="rounded border border-slate-200 p-3 text-sm">
                          <p className="font-medium">{payment.course.title}</p>
                          <p className="text-slate-600">
                            {payment.user.fullName} ({payment.user.email})
                          </p>
                          <p className="text-slate-600">
                            {payment.method.label} • {payment.method.type}
                          </p>
                          <p className="text-slate-700">
                            Amount: {payment.amount.toFixed(2)} • Status: {payment.status}
                          </p>
                          <PaymentProofActions
                            paymentId={payment.id}
                            accessToken={accessToken ?? ""}
                            proofContentType={payment.proofContentType}
                            proofFileName={payment.proofFileName}
                          />
                          {payment.status === "PENDING" ? (
                            <div className="mt-2 flex gap-2">
                              <button
                                type="button"
                                onClick={() => approveMutation.mutate(payment.id)}
                                className="rounded border border-emerald-300 px-3 py-1 text-xs text-emerald-700"
                              >
                                Approve
                              </button>
                              <button
                                type="button"
                                onClick={() => rejectMutation.mutate(payment.id)}
                                className="rounded border border-red-300 px-3 py-1 text-xs text-red-700"
                              >
                                Reject
                              </button>
                            </div>
                          ) : null}
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-500">No payment submissions yet.</p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                <div className="flex gap-2">
                  <Link href="/my-courses" className="rounded border border-slate-300 px-3 py-2 text-sm">
                    My Courses
                  </Link>
                  <Link href="/courses" className="rounded bg-slate-900 px-3 py-2 text-sm text-white">
                    Browse Courses
                  </Link>
                </div>

                <div className="rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-slate-700">My Instructors</p>
                      <p className="text-xs text-slate-500">Join multiple instructors using invite codes.</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => document.getElementById("student-invite-code")?.focus()}
                      className="rounded border border-slate-300 px-3 py-2 text-sm"
                    >
                      Add Instructor
                    </button>
                  </div>

                  <form onSubmit={onJoinInstructor} className="mt-4 flex flex-col gap-3 sm:flex-row">
                    <input
                      id="student-invite-code"
                      className="flex-1 rounded border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Enter invite code"
                      value={studentInviteCode}
                      onChange={(event) => {
                        setStudentInviteCode(event.target.value.toUpperCase());
                        if (studentJoinError) {
                          setStudentJoinError(null);
                        }
                      }}
                    />
                    <button
                      type="submit"
                      disabled={joinInstructorMutation.isPending}
                      className="rounded bg-slate-900 px-4 py-2 text-sm text-white disabled:opacity-60"
                    >
                      {joinInstructorMutation.isPending ? "Adding..." : "Add Instructor"}
                    </button>
                  </form>

                  {studentJoinError ? <p className="mt-3 text-xs text-red-600">{studentJoinError}</p> : null}

                  <div className="mt-4 space-y-2">
                    {studentInstructorsQuery.data?.length ? (
                      studentInstructorsQuery.data.map((item) => (
                        <div key={item.id} className="rounded border border-slate-200 p-3 text-sm">
                          <p className="font-medium">{item.instructor.fullName}</p>
                          <p className="text-slate-600">{item.instructor.email}</p>
                          <p className="mt-1 text-slate-500">
                            {item.instructor.tenant?.name ?? "Instructor organization"}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div className="rounded border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-500">
                        You have not joined any instructor yet.
                      </div>
                    )}
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                      <p className="text-lg font-semibold text-slate-900">Course Explorer</p>
                      <p className="text-sm text-slate-500">
                        Browse all followed instructors, filter by pricing, and search instantly.
                      </p>
                    </div>
                    <label className="block w-full max-w-md">
                      <span className="sr-only">Search courses</span>
                      <input
                        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm shadow-sm outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-200"
                        placeholder="Search courses..."
                        value={searchQuery}
                        onChange={(event) => setSearchQuery(event.target.value)}
                      />
                    </label>
                  </div>

                  <div className="mt-5 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                    <div className="flex flex-wrap gap-2">
                      {[
                        { value: "ALL", label: "All Courses" },
                        { value: "MY", label: "My Courses" },
                        { value: "INSTRUCTOR", label: "By Instructor" }
                      ].map((tab) => (
                        <button
                          key={tab.value}
                          type="button"
                          onClick={() => setActiveTab(tab.value as StudentTab)}
                          className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                            activeTab === tab.value
                              ? "bg-slate-900 text-white shadow-sm"
                              : "border border-slate-300 bg-white text-slate-700 hover:border-slate-400"
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {[
                        { value: "ALL", label: "All" },
                        { value: "FREE", label: "Free" },
                        { value: "PAID", label: "Paid" }
                      ].map((filter) => (
                        <button
                          key={filter.value}
                          type="button"
                          onClick={() => setFilterType(filter.value as CourseFilter)}
                          className={`rounded-full px-4 py-2 text-sm transition ${
                            filterType === filter.value
                              ? "bg-sky-100 text-sky-800"
                              : "border border-slate-300 text-slate-600 hover:border-slate-400"
                          }`}
                        >
                          {filter.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mt-6">
                    {studentCoursesQuery.isLoading || studentMyCoursesQuery.isLoading ? (
                      <p className="text-sm text-slate-500">Loading courses...</p>
                    ) : studentCoursesQuery.isError || studentMyCoursesQuery.isError ? (
                      <p className="text-sm text-red-600">Failed to load course dashboard.</p>
                    ) : filteredStudentCourses.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center">
                        <p className="text-base font-medium text-slate-700">{studentEmptyStateMessage}</p>
                        <p className="mt-2 text-sm text-slate-500">
                          Try another filter, search term, or join a new instructor.
                        </p>
                      </div>
                    ) : activeTab === "INSTRUCTOR" ? (
                      <div className="space-y-6">
                        {Object.entries(groupedCoursesByInstructor).map(([instructorName, courses]) => (
                          <section key={instructorName}>
                            <div className="mb-3 flex items-center justify-between">
                              <h2 className="text-lg font-semibold text-slate-900">{instructorName}</h2>
                              <span className="text-xs uppercase tracking-wide text-slate-400">
                                {courses.length} course{courses.length === 1 ? "" : "s"}
                              </span>
                            </div>
                            <div className="grid gap-3 md:grid-cols-2">
                              {courses.map((course) => (
                                <a
                                  key={course.id}
                                  href={`/courses/${course.id}`}
                                  className="rounded-2xl border border-slate-200 bg-gradient-to-br from-white to-slate-50 p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
                                >
                                  <div className="flex items-start justify-between gap-3">
                                    <div>
                                      <p className="text-lg font-semibold text-slate-900">{course.title}</p>
                                      <p className="mt-2 text-sm text-slate-600">{course.description}</p>
                                    </div>
                                    <span
                                      className={`rounded-full px-3 py-1 text-xs font-medium ${
                                        course.isPaid ? "bg-amber-100 text-amber-800" : "bg-emerald-100 text-emerald-800"
                                      }`}
                                    >
                                      {course.isPaid ? `Paid ${course.price?.toFixed(2) ?? "0.00"}` : "Free"}
                                    </span>
                                  </div>
                                  {course.isEnrolled ? (
                                    <p className="mt-4 text-xs font-medium text-sky-700">Enrolled</p>
                                  ) : null}
                                </a>
                              ))}
                            </div>
                          </section>
                        ))}
                      </div>
                    ) : (
                      <div className="grid gap-3 md:grid-cols-2">
                        {filteredStudentCourses.map((course) => (
                          <a
                            key={course.id}
                            href={`/courses/${course.id}`}
                            className="rounded-2xl border border-slate-200 bg-gradient-to-br from-white to-slate-50 p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <p className="text-xs uppercase tracking-wide text-slate-400">{course.instructorName}</p>
                                <p className="mt-1 text-lg font-semibold text-slate-900">{course.title}</p>
                                <p className="mt-2 text-sm text-slate-600">{course.description}</p>
                              </div>
                              <span
                                className={`rounded-full px-3 py-1 text-xs font-medium ${
                                  course.isPaid ? "bg-amber-100 text-amber-800" : "bg-emerald-100 text-emerald-800"
                                }`}
                              >
                                {course.isPaid ? `Paid ${course.price?.toFixed(2) ?? "0.00"}` : "Free"}
                              </span>
                            </div>
                            {course.isEnrolled ? (
                              <p className="mt-4 text-xs font-medium text-sky-700">Enrolled</p>
                            ) : null}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </main>
  );
}
