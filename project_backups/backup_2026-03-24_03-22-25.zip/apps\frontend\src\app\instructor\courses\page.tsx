"use client";

import { useQuery } from "@tanstack/react-query";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch } from "../../../lib/api/client";
import { BackButton } from "../../../components/back-button";
import { useRequireAuth } from "../../../hooks/use-require-auth";

interface Course {
  id: string;
  title: string;
  description?: string | null;
  isPaid: boolean;
  price?: number | null;
  status: "DRAFT" | "PUBLISHED";
  createdAt: string;
}

export default function InstructorCoursesPage() {
  const router = useRouter();
  const { accessToken, hasHydrated, isAuthorized } = useRequireAuth({ roles: ["INSTRUCTOR"] });
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [isPaid, setIsPaid] = useState(false);
  const [price, setPrice] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const coursesQuery = useQuery({
    queryKey: ["instructor-courses"],
    queryFn: () => apiFetch<Course[]>("/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && isAuthorized)
  });

  async function createCourse(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setSaving(true);

    try {
      const created = await apiFetch<Course>("/courses", {
        method: "POST",
        token: accessToken ?? undefined,
        body: JSON.stringify({
          title,
          description: description || undefined,
          isPaid,
          price: isPaid ? Number(price) : undefined
        })
      });
      setTitle("");
      setDescription("");
      setIsPaid(false);
      setPrice("");
      await coursesQuery.refetch();
      router.push(`/instructor/courses/${created.id}/builder`);
    } catch {
      setError("Could not create course");
    } finally {
      setSaving(false);
    }
  }

  async function toggleStatus(course: Course) {
    const next = course.status === "DRAFT" ? "PUBLISHED" : "DRAFT";
    await apiFetch(`/courses/${course.id}/status`, {
      method: "PATCH",
      token: accessToken ?? undefined,
      body: JSON.stringify({ status: next })
    });
    await coursesQuery.refetch();
  }

  return (
    <main className="mx-auto max-w-5xl p-8">
      <BackButton fallbackHref="/dashboard" />
      <h1 className="text-2xl font-semibold">Instructor Courses</h1>

      <form onSubmit={createCourse} className="mt-6 rounded-xl bg-white p-6 shadow">
        <h2 className="text-lg font-medium">Create Course</h2>
        <input
          className="mt-3 w-full rounded border px-3 py-2"
          placeholder="Course title"
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          required
        />
        <textarea
          className="mt-3 w-full rounded border px-3 py-2"
          placeholder="Description"
          value={description}
          onChange={(event) => setDescription(event.target.value)}
        />
        <div className="mt-3 flex items-center gap-2">
          <input
            id="course-paid-toggle"
            type="checkbox"
            checked={isPaid}
            onChange={(event) => setIsPaid(event.target.checked)}
          />
          <label htmlFor="course-paid-toggle" className="text-sm">
            Paid Course
          </label>
        </div>
        {isPaid ? (
          <input
            className="mt-3 w-full rounded border px-3 py-2"
            placeholder="Price (e.g. 199.99)"
            type="number"
            min={0.01}
            step="0.01"
            value={price}
            onChange={(event) => setPrice(event.target.value)}
            required
          />
        ) : null}
        {error ? <p className="mt-2 text-sm text-red-600">{error}</p> : null}
        <button
          type="submit"
          disabled={saving}
          className="mt-3 rounded bg-slate-900 px-4 py-2 text-white"
        >
          {saving ? "Creating..." : "Create Course"}
        </button>
      </form>

      <section className="mt-8 space-y-3">
        <h2 className="text-lg font-medium">Manage Courses</h2>
        {coursesQuery.data?.map((course) => (
          <div key={course.id} className="rounded-xl bg-white p-4 shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{course.title}</p>
                <p className="text-sm text-slate-600">{course.description}</p>
                <p className="text-xs text-slate-500">
                  {course.isPaid ? `Paid - ${course.price?.toFixed(2) ?? "0.00"}` : "Free"}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleStatus(course)}
                  className="rounded border px-3 py-2 text-sm"
                >
                  {course.status === "DRAFT" ? "Publish" : "Set Draft"}
                </button>
                <a
                  href={`/instructor/courses/${course.id}/builder`}
                  className="rounded bg-slate-900 px-3 py-2 text-sm text-white"
                >
                  Builder
                </a>
              </div>
            </div>
          </div>
        ))}
      </section>
    </main>
  );
}
