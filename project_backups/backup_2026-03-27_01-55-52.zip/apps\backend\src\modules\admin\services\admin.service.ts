import { Injectable, NotFoundException } from "@nestjs/common";
import { PaymentStatus, Prisma, UserRole } from "@prisma/client";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import {
  AdminCoursesQueryDto,
  AdminPaymentsQueryDto,
  AdminTenantsQueryDto,
  AdminUsersQueryDto
} from "../dto/admin-query.dto";
import { UsersService } from "../../users/services/users.service";
import { PlansService } from "../../plans/services/plans.service";
import { CreatePlanDto, UpdatePlanDto } from "../../plans/dto/plan.dto";
import { SubscriptionsService } from "../../subscriptions/services/subscriptions.service";

@Injectable()
export class AdminService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly usersService: UsersService,
    private readonly plansService: PlansService,
    private readonly subscriptionsService: SubscriptionsService
  ) {}

  async getOverview() {
    const [users, tenants, plans, courses, payments, unreadNotifications] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.tenant.count(),
      this.prisma.plan.count(),
      this.prisma.course.count(),
      this.prisma.payment.aggregate({
        _count: { id: true },
        _sum: { amount: true },
        where: { status: PaymentStatus.APPROVED }
      }),
      this.prisma.notification.count({ where: { isRead: false } })
    ]);

    return {
      totals: {
        users,
        tenants,
        plans,
        courses,
        approvedPayments: payments._count.id,
        approvedRevenue: payments._sum.amount ?? 0,
        unreadNotifications
      }
    };
  }

  async listTenants(query: AdminTenantsQueryDto) {
    const where: Prisma.TenantWhereInput = {};

    if (query.search?.trim()) {
      where.OR = [
        { name: { contains: query.search.trim(), mode: "insensitive" } },
        { inviteCode: { contains: query.search.trim().toUpperCase() } }
      ];
    }

    if (query.isActive !== undefined) {
      where.isActive = query.isActive === "true";
    }

    const tenants = await this.prisma.tenant.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        owner: {
          select: {
            id: true,
            fullName: true,
            email: true,
            isActive: true
          }
        },
        _count: {
          select: {
            users: true,
            courses: true,
            payments: true,
            enrollments: true
          }
        },
        plan: true
      }
    });

    return tenants.map((tenant) => ({
      ...tenant,
      usage: {
        usersCount: tenant._count.users,
        coursesCount: tenant._count.courses,
        paymentsCount: tenant._count.payments,
        enrollmentsCount: tenant._count.enrollments
      }
    }));
  }

  async getTenantDetail(id: string) {
    const tenant = await this.prisma.tenant.findUnique({
      where: { id },
      include: {
        owner: {
          select: {
            id: true,
            fullName: true,
            email: true,
            isActive: true
          }
        },
        plan: true,
        users: {
          orderBy: { createdAt: "desc" },
          select: {
            id: true,
            fullName: true,
            email: true,
            role: true,
            isActive: true,
            createdAt: true
          }
        },
        courses: {
          orderBy: { createdAt: "desc" },
          select: {
            id: true,
            title: true,
            status: true,
            isPaid: true,
            price: true,
            createdAt: true,
            instructor: {
              select: {
                id: true,
                fullName: true
              }
            },
            _count: {
              select: {
                enrollments: true
              }
            }
          }
        }
      }
    });

    if (!tenant) {
      throw new NotFoundException("Tenant not found");
    }

    const [payments, approvedRevenue, recentNotifications, usage, subscription] = await Promise.all([
      this.prisma.payment.count({ where: { tenantId: id } }),
      this.prisma.payment.aggregate({
        where: { tenantId: id, status: PaymentStatus.APPROVED },
        _sum: { amount: true }
      }),
      this.prisma.notification.findMany({
        where: { tenantId: id },
        orderBy: { createdAt: "desc" },
        take: 8,
        select: {
          id: true,
          type: true,
          title: true,
          message: true,
          createdAt: true
        }
      }),
      this.plansService.getTenantUsage(id),
      this.subscriptionsService.getAdminTenantSubscription(id)
    ]);

    return {
      ...tenant,
      usage: {
        usersCount: tenant.users.length,
        coursesCount: tenant.courses.length,
        studentsCount: usage.studentsCount,
        instructorsCount: usage.instructorsCount,
        adminsCount: usage.adminsCount,
        storageUsedMb: usage.storageUsedMb,
        paymentsCount: payments,
        approvedRevenue: approvedRevenue._sum.amount ?? 0
      },
      recentNotifications,
      subscription
    };
  }

  async setTenantStatus(id: string, isActive: boolean) {
    const tenant = await this.prisma.tenant.findUnique({
      where: { id },
      select: { id: true }
    });

    if (!tenant) {
      throw new NotFoundException("Tenant not found");
    }

    return this.prisma.tenant.update({
      where: { id },
      data: {
        isActive,
        deactivatedAt: isActive ? null : new Date()
      }
    });
  }

  listPlans() {
    return this.plansService.listPlans();
  }

  createPlan(dto: CreatePlanDto) {
    return this.plansService.createPlan(dto);
  }

  updatePlan(planId: string, dto: UpdatePlanDto) {
    return this.plansService.updatePlan(planId, dto);
  }

  archivePlan(planId: string) {
    return this.plansService.archivePlan(planId);
  }

  async listUsers(query: AdminUsersQueryDto) {
    const where: Prisma.UserWhereInput = {};

    if (query.search?.trim()) {
      const search = query.search.trim();
      where.OR = [
        { fullName: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } }
      ];
    }

    if (query.role) {
      where.role = query.role as UserRole;
    }

    if (query.tenantId) {
      where.tenantId = query.tenantId;
    }

    if (query.isActive !== undefined) {
      where.isActive = query.isActive === "true";
    }

    const users = await this.prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        fullName: true,
        email: true,
        role: true,
        isActive: true,
        deactivatedAt: true,
        createdAt: true,
        tenantId: true,
        tenant: {
          select: {
            id: true,
            name: true,
            isActive: true
          }
        },
        _count: {
          select: {
            instructorCourses: true,
            enrollments: true,
            certificates: true,
            joinedInstructors: true,
            followedByStudents: true
          }
        }
      }
    });

    return users;
  }

  async getUserDetail(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        fullName: true,
        email: true,
        bio: true,
        profileImage: true,
        role: true,
        isActive: true,
        deactivatedAt: true,
        createdAt: true,
        tenantId: true,
        tenant: {
          select: {
            id: true,
            name: true,
            isActive: true
          }
        },
        _count: {
          select: {
            instructorCourses: true,
            enrollments: true,
            certificates: true,
            joinedInstructors: true,
            followedByStudents: true,
            payments: true
          }
        }
      }
    });

    if (!user) {
      throw new NotFoundException("User not found");
    }

    const [recentPayments, recentEnrollments] = await Promise.all([
      this.prisma.payment.findMany({
        where: { userId: id },
        orderBy: { createdAt: "desc" },
        take: 6,
        select: {
          id: true,
          status: true,
          amount: true,
          createdAt: true,
          course: { select: { id: true, title: true } }
        }
      }),
      this.prisma.enrollment.findMany({
        where: { userId: id },
        orderBy: { createdAt: "desc" },
        take: 6,
        select: {
          id: true,
          createdAt: true,
          course: { select: { id: true, title: true } }
        }
      })
    ]);

    return {
      user: {
        ...user,
        profileImage: this.usersService.resolveProfileImageUrl(user.id, user.profileImage)
      },
      recentPayments,
      recentEnrollments
    };
  }

  async setUserStatus(id: string, isActive: boolean) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: { id: true }
    });

    if (!user) {
      throw new NotFoundException("User not found");
    }

    return this.usersService.setActiveStatus(id, isActive);
  }

  async listCourses(query: AdminCoursesQueryDto) {
    const where: Prisma.CourseWhereInput = {};

    if (query.tenantId) {
      where.tenantId = query.tenantId;
    }
    if (query.instructorId) {
      where.instructorId = query.instructorId;
    }
    if (query.status) {
      where.status = query.status;
    }
    if (query.search?.trim()) {
      const search = query.search.trim();
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { category: { contains: search, mode: "insensitive" } }
      ];
    }

    return this.prisma.course.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        tenant: { select: { id: true, name: true, isActive: true } },
        instructor: { select: { id: true, fullName: true, email: true, isActive: true } },
        _count: { select: { enrollments: true, payments: true, reviews: true } }
      }
    });
  }

  async listPayments(query: AdminPaymentsQueryDto) {
    const where: Prisma.PaymentWhereInput = {};

    if (query.tenantId) {
      where.tenantId = query.tenantId;
    }
    if (query.instructorId) {
      where.course = { instructorId: query.instructorId };
    }
    if (query.status) {
      where.status = query.status as PaymentStatus;
    }

    return this.prisma.payment.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        tenant: { select: { id: true, name: true, isActive: true } },
        course: {
          select: {
            id: true,
            title: true,
            instructor: { select: { id: true, fullName: true, email: true } }
          }
        },
        user: { select: { id: true, fullName: true, email: true, isActive: true } },
        method: { select: { id: true, label: true, type: true } }
      }
    });
  }

  async getActivity() {
    const [recentUsers, recentCourses, recentPayments, recentNotifications] = await Promise.all([
      this.prisma.user.findMany({
        orderBy: { createdAt: "desc" },
        take: 8,
        select: { id: true, fullName: true, role: true, createdAt: true }
      }),
      this.prisma.course.findMany({
        orderBy: { createdAt: "desc" },
        take: 8,
        select: { id: true, title: true, status: true, createdAt: true }
      }),
      this.prisma.payment.findMany({
        orderBy: { createdAt: "desc" },
        take: 8,
        select: {
          id: true,
          status: true,
          amount: true,
          createdAt: true,
          user: { select: { fullName: true } },
          course: { select: { title: true } }
        }
      }),
      this.prisma.notification.findMany({
        orderBy: { createdAt: "desc" },
        take: 8,
        select: { id: true, type: true, title: true, message: true, createdAt: true }
      })
    ]);

    return {
      recentUsers,
      recentCourses,
      recentPayments,
      recentNotifications
    };
  }
}
