import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from "@nestjs/common";
import { Roles } from "../../../shared/decorators/roles.decorator";
import { RolesGuard } from "../../../shared/guards/roles.guard";
import { JwtAuthGuard } from "../../auth/guards/jwt-auth.guard";
import {
  AdminCoursesQueryDto,
  AdminPaymentsQueryDto,
  AdminTenantsQueryDto,
  AdminUsersQueryDto,
  UpdateAdminStatusDto
} from "../dto/admin-query.dto";
import { AdminService } from "../services/admin.service";
import { AssignTenantPlanDto, CreatePlanDto, UpdatePlanDto } from "../../plans/dto/plan.dto";

@Controller("admin")
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles("ADMIN")
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get("overview")
  getOverview() {
    return this.adminService.getOverview();
  }

  @Get("tenants")
  listTenants(@Query() query: AdminTenantsQueryDto) {
    return this.adminService.listTenants(query);
  }

  @Get("plans")
  listPlans() {
    return this.adminService.listPlans();
  }

  @Post("plans")
  createPlan(@Body() dto: CreatePlanDto) {
    return this.adminService.createPlan(dto);
  }

  @Patch("plans/:id")
  updatePlan(@Param("id") id: string, @Body() dto: UpdatePlanDto) {
    return this.adminService.updatePlan(id, dto);
  }

  @Get("tenants/:id")
  getTenantDetail(@Param("id") id: string) {
    return this.adminService.getTenantDetail(id);
  }

  @Patch("tenants/:id/plan")
  assignTenantPlan(@Param("id") id: string, @Body() dto: AssignTenantPlanDto) {
    return this.adminService.assignTenantPlan(id, dto);
  }

  @Patch("tenants/:id/status")
  setTenantStatus(@Param("id") id: string, @Body() dto: UpdateAdminStatusDto) {
    return this.adminService.setTenantStatus(id, dto.isActive);
  }

  @Get("users")
  listUsers(@Query() query: AdminUsersQueryDto) {
    return this.adminService.listUsers(query);
  }

  @Get("users/:id")
  getUserDetail(@Param("id") id: string) {
    return this.adminService.getUserDetail(id);
  }

  @Patch("users/:id/status")
  setUserStatus(@Param("id") id: string, @Body() dto: UpdateAdminStatusDto) {
    return this.adminService.setUserStatus(id, dto.isActive);
  }

  @Get("courses")
  listCourses(@Query() query: AdminCoursesQueryDto) {
    return this.adminService.listCourses(query);
  }

  @Get("payments")
  listPayments(@Query() query: AdminPaymentsQueryDto) {
    return this.adminService.listPayments(query);
  }

  @Get("activity")
  getActivity() {
    return this.adminService.getActivity();
  }
}
