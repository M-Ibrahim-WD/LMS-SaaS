import { Module } from "@nestjs/common";
import { AdminController } from "./controllers/admin.controller";
import { AdminService } from "./services/admin.service";
import { PlansModule } from "../plans/plans.module";
import { UsersModule } from "../users/users.module";

@Module({
  imports: [UsersModule, PlansModule],
  controllers: [AdminController],
  providers: [AdminService]
})
export class AdminModule {}
