import assert from "node:assert/strict";
import test from "node:test";
import { BadRequestException } from "@nestjs/common";
import { PlansService } from "./plans.service";
import { createAsyncMock } from "../../../test/mock-utils";

test("ensureDefaultPlan creates the default plan when missing", async () => {
  const prisma = {
    plan: {
      findUnique: createAsyncMock(async () => null),
      create: createAsyncMock(async () => ({
        id: "plan-1",
        code: "FREE"
      }))
    }
  };

  const service = new PlansService(prisma as never);
  const result = await service.ensureDefaultPlan();

  assert.equal(result.code, "FREE");
  assert.equal(prisma.plan.create.calls.length, 1);
});

test("assertCanCreateCourse rejects when tenant reached plan course limit", async () => {
  const prisma = {
    tenant: {
      findUnique: createAsyncMock(async () => ({
        id: "tenant-1",
        plan: {
          id: "plan-1",
          code: "FREE",
          name: "Free",
          maxCourses: 2,
          maxStudents: 100,
          maxStorageMb: 512,
          hasAdvancedAnalytics: false,
          hasOnlinePayments: false,
          isActive: true
        }
      })),
      update: createAsyncMock(async () => undefined)
    },
    course: {
      count: createAsyncMock(async () => 2)
    },
    studentInstructor: {
      findMany: createAsyncMock(async () => [])
    },
    user: {
      count: createAsyncMock(async () => 0)
    },
    plan: {
      findUnique: createAsyncMock(async () => ({
        id: "plan-1",
        code: "FREE",
        name: "Free",
        maxCourses: 2,
        maxStudents: 100,
        maxStorageMb: 512,
        hasAdvancedAnalytics: false,
        hasOnlinePayments: false,
        isActive: true
      })),
      create: createAsyncMock(async () => undefined)
    }
  };

  const service = new PlansService(prisma as never);

  await assert.rejects(
    () => service.assertCanCreateCourse("tenant-1"),
    (error: unknown) => error instanceof BadRequestException
  );
});
