import { Type } from "class-transformer";
import {
  IsBoolean,
  IsInt,
  IsOptional,
  IsString,
  Min,
  MinLength
} from "class-validator";

export class CreatePlanDto {
  @IsString()
  @MinLength(2)
  code!: string;

  @IsString()
  @MinLength(2)
  name!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  maxCourses!: number;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  maxStudents!: number;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  maxStorageMb!: number;

  @Type(() => Boolean)
  @IsBoolean()
  hasAdvancedAnalytics!: boolean;

  @Type(() => Boolean)
  @IsBoolean()
  hasOnlinePayments!: boolean;

  @Type(() => Boolean)
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class UpdatePlanDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  code?: string;

  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @Type(() => Number)
  @IsOptional()
  @IsInt()
  @Min(1)
  maxCourses?: number;

  @Type(() => Number)
  @IsOptional()
  @IsInt()
  @Min(1)
  maxStudents?: number;

  @Type(() => Number)
  @IsOptional()
  @IsInt()
  @Min(1)
  maxStorageMb?: number;

  @Type(() => Boolean)
  @IsOptional()
  @IsBoolean()
  hasAdvancedAnalytics?: boolean;

  @Type(() => Boolean)
  @IsOptional()
  @IsBoolean()
  hasOnlinePayments?: boolean;

  @Type(() => Boolean)
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class AssignTenantPlanDto {
  @IsString()
  planId!: string;
}
