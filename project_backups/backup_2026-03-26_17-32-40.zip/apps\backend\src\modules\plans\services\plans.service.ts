import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import { AssignTenantPlanDto, CreatePlanDto, UpdatePlanDto } from "../dto/plan.dto";

@Injectable()
export class PlansService {
  constructor(private readonly prisma: PrismaService) {}

  private readonly defaultPlanCode = "FREE";

  private normalizeCode(code: string) {
    return code.trim().toUpperCase().replace(/\s+/g, "_");
  }

  async ensureDefaultPlan() {
    const existing = await this.prisma.plan.findUnique({
      where: { code: this.defaultPlanCode }
    });

    if (existing) {
      return existing;
    }

    return this.prisma.plan.create({
      data: {
        code: this.defaultPlanCode,
        name: "Free",
        description: "Default starter plan for new instructor workspaces.",
        maxCourses: 10,
        maxStudents: 200,
        maxStorageMb: 512,
        hasAdvancedAnalytics: false,
        hasOnlinePayments: false,
        isActive: true
      }
    });
  }

  listPlans() {
    return this.prisma.plan.findMany({
      orderBy: [{ isActive: "desc" }, { createdAt: "asc" }],
      include: {
        _count: {
          select: {
            tenants: true
          }
        }
      }
    });
  }

  async createPlan(dto: CreatePlanDto) {
    try {
      return await this.prisma.plan.create({
        data: {
          code: this.normalizeCode(dto.code),
          name: dto.name.trim(),
          description: dto.description?.trim() || null,
          maxCourses: dto.maxCourses,
          maxStudents: dto.maxStudents,
          maxStorageMb: dto.maxStorageMb,
          hasAdvancedAnalytics: dto.hasAdvancedAnalytics,
          hasOnlinePayments: dto.hasOnlinePayments,
          isActive: dto.isActive ?? true
        }
      });
    } catch {
      throw new ConflictException("A plan with this code already exists");
    }
  }

  async updatePlan(planId: string, dto: UpdatePlanDto) {
    const existing = await this.prisma.plan.findUnique({
      where: { id: planId },
      select: { id: true }
    });

    if (!existing) {
      throw new NotFoundException("Plan not found");
    }

    try {
      return await this.prisma.plan.update({
        where: { id: planId },
        data: {
          ...(dto.code !== undefined ? { code: this.normalizeCode(dto.code) } : {}),
          ...(dto.name !== undefined ? { name: dto.name.trim() } : {}),
          ...(dto.description !== undefined ? { description: dto.description.trim() || null } : {}),
          ...(dto.maxCourses !== undefined ? { maxCourses: dto.maxCourses } : {}),
          ...(dto.maxStudents !== undefined ? { maxStudents: dto.maxStudents } : {}),
          ...(dto.maxStorageMb !== undefined ? { maxStorageMb: dto.maxStorageMb } : {}),
          ...(dto.hasAdvancedAnalytics !== undefined ? { hasAdvancedAnalytics: dto.hasAdvancedAnalytics } : {}),
          ...(dto.hasOnlinePayments !== undefined ? { hasOnlinePayments: dto.hasOnlinePayments } : {}),
          ...(dto.isActive !== undefined ? { isActive: dto.isActive } : {})
        }
      });
    } catch {
      throw new ConflictException("A plan with this code already exists");
    }
  }

  async assignPlanToTenant(tenantId: string, dto: AssignTenantPlanDto) {
    const [tenant, plan] = await Promise.all([
      this.prisma.tenant.findUnique({ where: { id: tenantId }, select: { id: true } }),
      this.prisma.plan.findUnique({ where: { id: dto.planId }, select: { id: true, isActive: true } })
    ]);

    if (!tenant) {
      throw new NotFoundException("Tenant not found");
    }

    if (!plan) {
      throw new NotFoundException("Plan not found");
    }

    if (!plan.isActive) {
      throw new BadRequestException("Inactive plans cannot be assigned");
    }

    return this.prisma.tenant.update({
      where: { id: tenantId },
      data: {
        planId: dto.planId
      },
      include: {
        plan: true
      }
    });
  }

  async getTenantPlan(tenantId: string) {
    const tenant = await this.prisma.tenant.findUnique({
      where: { id: tenantId },
      select: {
        id: true,
        plan: true
      }
    });

    if (!tenant) {
      throw new NotFoundException("Tenant not found");
    }

    if (tenant.plan) {
      return tenant.plan;
    }

    const defaultPlan = await this.ensureDefaultPlan();
    await this.prisma.tenant.update({
      where: { id: tenantId },
      data: { planId: defaultPlan.id }
    });

    return defaultPlan;
  }

  async getTenantUsage(tenantId: string) {
    const [coursesCount, distinctStudents, instructorsCount, adminsCount] = await Promise.all([
      this.prisma.course.count({ where: { tenantId } }),
      this.prisma.studentInstructor.findMany({
        where: {
          instructor: {
            tenantId
          }
        },
        distinct: ["studentId"],
        select: {
          studentId: true
        }
      }),
      this.prisma.user.count({ where: { tenantId, role: "INSTRUCTOR" } }),
      this.prisma.user.count({ where: { tenantId, role: "ADMIN" } })
    ]);

    return {
      coursesCount,
      studentsCount: distinctStudents.length,
      instructorsCount,
      adminsCount,
      storageUsedMb: 0
    };
  }

  async assertCanCreateCourse(tenantId: string) {
    const [plan, usage] = await Promise.all([this.getTenantPlan(tenantId), this.getTenantUsage(tenantId)]);

    if (usage.coursesCount >= plan.maxCourses) {
      throw new BadRequestException(
        `Plan limit reached: this workspace can only create ${plan.maxCourses} courses on the current plan.`
      );
    }
  }

  async assertCanAddStudentToTenant(tenantId: string) {
    const [plan, usage] = await Promise.all([this.getTenantPlan(tenantId), this.getTenantUsage(tenantId)]);

    if (usage.studentsCount >= plan.maxStudents) {
      throw new BadRequestException(
        `Plan limit reached: this workspace can only have ${plan.maxStudents} students on the current plan.`
      );
    }
  }
}
