import { Module } from "@nestjs/common";
import { PlansModule } from "../plans/plans.module";
import { CoursesController, CoursesPublicController } from "./controllers/courses.controller";
import { CoursesService } from "./services/courses.service";

@Module({
  imports: [PlansModule],
  controllers: [CoursesController, CoursesPublicController],
  providers: [CoursesService],
  exports: [CoursesService]
})
export class CoursesModule {}
