import { Module } from "@nestjs/common";
import { PlansModule } from "../plans/plans.module";
import { StudentInstructorsController } from "./controllers/student-instructors.controller";
import { StudentInstructorsService } from "./services/student-instructors.service";

@Module({
  imports: [PlansModule],
  controllers: [StudentInstructorsController],
  providers: [StudentInstructorsService],
  exports: [StudentInstructorsService]
})
export class StudentInstructorsModule {}
