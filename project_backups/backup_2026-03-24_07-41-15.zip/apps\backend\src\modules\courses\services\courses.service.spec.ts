import assert from "node:assert/strict";
import test from "node:test";
import { ForbiddenException } from "@nestjs/common";
import { CoursesService } from "./courses.service";
import { createAsyncMock } from "../../../test/mock-utils";

test("getOne rejects student access when the instructor is not followed", async () => {
  const prisma = {
    enrollment: {
      findFirst: createAsyncMock(async () => null)
    },
    course: {
      findFirst: createAsyncMock(async () => null)
    }
  };
  const studentAccessService = {
    getFollowedInstructorWhere: () => ({}) ,
    getAccessiblePublishedCourseForStudent: createAsyncMock(async () => null)
  };

  const service = new CoursesService(prisma as never, studentAccessService as never);

  await assert.rejects(
    () =>
      service.getOne(
        {
          sub: "student-1",
          role: "STUDENT",
          email: "student@example.com",
          tenantId: null
        },
        "course-1"
      ),
    (error: unknown) =>
      error instanceof ForbiddenException && error.message === "Join this instructor first"
  );
});
