"use client";

import { useQuery } from "@tanstack/react-query";
import { ContentCard } from "../../components/content-card";
import { PageShell } from "../../components/page-shell";
import { StatusBanner } from "../../components/status-banner";
import { useRequireAuth } from "../../hooks/use-require-auth";
import { apiFetch } from "../../lib/api/client";

interface Profile {
  id: string;
  email: string;
  fullName: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  tenantId: string | null;
  tenant?: {
    id: string;
    name: string;
  } | null;
  createdAt: string;
}

interface InstructorStats {
  studentsCount: number;
  totalRevenue: number;
}

export default function ProfilePage() {
  const { accessToken, hasHydrated } = useRequireAuth();

  const profileQuery = useQuery({
    queryKey: ["profile", "me"],
    queryFn: () => apiFetch<Profile>("/auth/me", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const instructorStatsQuery = useQuery({
    queryKey: ["instructor", "stats"],
    queryFn: () => apiFetch<InstructorStats>("/instructor/stats", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && profileQuery.data?.role === "INSTRUCTOR")
  });

  if (!hasHydrated) {
    return <main className="p-8">Loading session...</main>;
  }

  const formattedRevenue = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2
  }).format(instructorStatsQuery.data?.totalRevenue ?? 0);

  return (
    <PageShell title="Profile" description="Account details and instructor performance overview." backHref="/dashboard" maxWidthClassName="max-w-3xl">
      {profileQuery.isLoading ? <StatusBanner>Loading profile...</StatusBanner> : null}
      {profileQuery.isError ? <StatusBanner variant="error">Failed to load profile.</StatusBanner> : null}
      {profileQuery.data ? (
        <div className="mt-6 grid gap-4 md:grid-cols-[minmax(0,2fr)_minmax(260px,1fr)]">
          <ContentCard className="space-y-2 p-6">
            <p>
              <span className="font-medium">Name:</span> {profileQuery.data.fullName}
            </p>
            <p>
              <span className="font-medium">Email:</span> {profileQuery.data.email}
            </p>
            <p>
              <span className="font-medium">Role:</span> {profileQuery.data.role}
            </p>
            <p>
              <span className="font-medium">Tenant:</span>{" "}
              {profileQuery.data.tenant?.name ?? profileQuery.data.tenantId ?? "Not assigned"}
            </p>
          </ContentCard>

          {profileQuery.data.role === "INSTRUCTOR" ? (
            <div className="rounded-2xl border border-slate-200 bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-800 p-6 text-white shadow-sm">
              <p className="text-xs uppercase tracking-[0.2em] text-slate-300">Instructor Stats</p>
              {instructorStatsQuery.isLoading ? (
                <p className="mt-4 text-sm text-slate-200">Loading instructor stats...</p>
              ) : instructorStatsQuery.isError ? (
                <p className="mt-4 text-sm text-rose-200">Failed to load instructor stats.</p>
              ) : (
                <div className="mt-4 space-y-4">
                  <div className="rounded-2xl bg-white/10 p-4 backdrop-blur-sm">
                    <p className="text-xs uppercase tracking-[0.16em] text-slate-300">Students</p>
                    <p className="mt-2 text-4xl font-semibold leading-none">
                      {instructorStatsQuery.data?.studentsCount ?? 0}
                    </p>
                    <p className="mt-3 text-sm text-slate-200">
                      Distinct students linked through tenant joining or course enrollment.
                    </p>
                  </div>

                  <div className="rounded-2xl bg-emerald-400/15 p-4 backdrop-blur-sm">
                    <p className="text-xs uppercase tracking-[0.16em] text-emerald-100">Total Revenue</p>
                    <p className="mt-2 text-3xl font-semibold leading-none">{formattedRevenue}</p>
                    <p className="mt-3 text-sm text-emerald-50">
                      Sum of approved manual payments for courses you own.
                    </p>
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </div>
      ) : null}
    </PageShell>
  );
}
