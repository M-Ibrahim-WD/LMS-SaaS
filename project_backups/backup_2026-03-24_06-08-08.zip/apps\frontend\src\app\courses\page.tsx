"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { apiFetch } from "../../lib/api/client";
import { ContentCard } from "../../components/content-card";
import { EmptyState } from "../../components/empty-state";
import { PageShell } from "../../components/page-shell";
import { StatusBanner } from "../../components/status-banner";
import { useAuthStore } from "../../store/auth.store";

interface Course {
  id: string;
  title: string;
  description?: string | null;
  isPaid: boolean;
  price?: number | null;
  status: "DRAFT" | "PUBLISHED";
  instructor?: {
    id: string;
    fullName: string;
  };
}

export default function CoursesPage() {
  const accessToken = useAuthStore((state) => state.accessToken);
  const user = useAuthStore((state) => state.user);
  const coursesQuery = useQuery({
    queryKey: ["courses"],
    queryFn: () => apiFetch<Course[]>("/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken)
  });

  const coursesByInstructor = (coursesQuery.data ?? []).reduce<Record<string, Course[]>>((groups, course) => {
    const key = course.instructor?.fullName ?? "Your Courses";
    if (!groups[key]) {
      groups[key] = [];
    }
    groups[key].push(course);
    return groups;
  }, {});

  return (
    <PageShell
      title={user?.role === "INSTRUCTOR" ? "My Courses" : "Courses"}
      description="Browse the courses available in your current LMS workspace."
      backHref="/dashboard"
      actions={
        <>
          {user?.role === "INSTRUCTOR" ? (
            <Link href="/instructor/courses" className="rounded-lg bg-slate-900 px-4 py-2 text-sm text-white">
              Open Course Manager
            </Link>
          ) : null}
          {user?.role === "STUDENT" ? (
            <Link href="/my-courses" className="rounded-lg bg-slate-900 px-4 py-2 text-sm text-white">
              My Courses
            </Link>
          ) : null}
        </>
      }
    >
      <div className="mt-6 space-y-6">
        {coursesQuery.isLoading ? <StatusBanner>Loading courses...</StatusBanner> : null}
        {coursesQuery.isError ? <StatusBanner variant="error">Failed to load courses.</StatusBanner> : null}
        {!coursesQuery.isLoading && !coursesQuery.isError && Object.keys(coursesByInstructor).length === 0 ? (
          <EmptyState
            title="No courses found"
            description="Courses will appear here once instructors publish them."
          />
        ) : null}

        {Object.entries(coursesByInstructor).map(([instructorName, courses]) => (
          <section key={instructorName}>
            {user?.role === "STUDENT" ? (
              <h2 className="mb-3 text-lg font-semibold text-slate-800">{instructorName}</h2>
            ) : null}
            <div className="grid gap-3">
              {courses.map((course) => (
                <Link key={course.id} href={`/courses/${course.id}`}>
                  <ContentCard className="transition hover:border-slate-300 hover:shadow-md">
                    <p className="font-medium">{course.title}</p>
                    <p className="text-sm text-slate-600">{course.description}</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {course.isPaid ? `Paid - ${course.price?.toFixed(2) ?? "0.00"}` : "Free"}
                    </p>
                  </ContentCard>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </PageShell>
  );
}
