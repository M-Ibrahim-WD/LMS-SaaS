"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ContentCard } from "../../components/content-card";
import { EmptyState } from "../../components/empty-state";
import { PageShell } from "../../components/page-shell";
import { StatusBanner } from "../../components/status-banner";
import { useRequireAuth } from "../../hooks/use-require-auth";
import { apiFetch } from "../../lib/api/client";

interface OverviewResponse {
  totals: {
    users: number;
    tenants: number;
    courses: number;
    approvedPayments: number;
    approvedRevenue: number;
    unreadNotifications: number;
  };
}

interface TenantListItem {
  id: string;
  name: string;
  inviteCode: string;
  isActive: boolean;
  deactivatedAt?: string | null;
  createdAt: string;
  owner?: {
    id: string;
    fullName: string;
    email: string;
    isActive: boolean;
  } | null;
  usage: {
    usersCount: number;
    coursesCount: number;
    paymentsCount: number;
    enrollmentsCount: number;
  };
}

interface TenantDetail extends TenantListItem {
  usage: TenantListItem["usage"] & {
    approvedRevenue: number;
  };
  users: Array<{
    id: string;
    fullName: string;
    email: string;
    role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
    isActive: boolean;
    createdAt: string;
  }>;
  courses: Array<{
    id: string;
    title: string;
    status: "DRAFT" | "PUBLISHED";
    isPaid: boolean;
    price?: number | null;
    createdAt: string;
    instructor?: {
      id: string;
      fullName: string;
    } | null;
    _count: {
      enrollments: number;
    };
  }>;
  recentNotifications: Array<{
    id: string;
    type: string;
    title: string;
    message: string;
    createdAt: string;
  }>;
}

interface AdminUser {
  id: string;
  fullName: string;
  email: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  isActive: boolean;
  deactivatedAt?: string | null;
  createdAt: string;
  tenantId?: string | null;
  tenant?: {
    id: string;
    name: string;
    isActive: boolean;
  } | null;
  _count: {
    instructorCourses: number;
    enrollments: number;
    certificates: number;
    joinedInstructors: number;
    followedByStudents: number;
  };
}

interface UserDetailResponse {
  user: AdminUser & {
    bio?: string | null;
    profileImage?: string | null;
    _count: AdminUser["_count"] & {
      payments: number;
    };
  };
  recentPayments: Array<{
    id: string;
    status: "PENDING" | "APPROVED" | "REJECTED";
    amount: number;
    createdAt: string;
    course: { id: string; title: string };
  }>;
  recentEnrollments: Array<{
    id: string;
    createdAt: string;
    course: { id: string; title: string };
  }>;
}

interface AdminCourse {
  id: string;
  title: string;
  status: "DRAFT" | "PUBLISHED";
  isPaid: boolean;
  price?: number | null;
  category?: string | null;
  level: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
  createdAt: string;
  tenant: {
    id: string;
    name: string;
    isActive: boolean;
  };
  instructor: {
    id: string;
    fullName: string;
    email: string;
    isActive: boolean;
  };
  _count: {
    enrollments: number;
    payments: number;
    reviews: number;
  };
}

interface AdminPayment {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  createdAt: string;
  tenant: {
    id: string;
    name: string;
    isActive: boolean;
  };
  course: {
    id: string;
    title: string;
    instructor?: {
      id: string;
      fullName: string;
      email: string;
    } | null;
  };
  user: {
    id: string;
    fullName: string;
    email: string;
    isActive: boolean;
  };
  method: {
    id: string;
    label: string;
    type: string;
  };
}

interface ActivityResponse {
  recentUsers: Array<{ id: string; fullName: string; role: string; createdAt: string }>;
  recentCourses: Array<{ id: string; title: string; status: string; createdAt: string }>;
  recentPayments: Array<{
    id: string;
    status: string;
    amount: number;
    createdAt: string;
    user: { fullName: string };
    course: { title: string };
  }>;
  recentNotifications: Array<{
    id: string;
    type: string;
    title: string;
    message: string;
    createdAt: string;
  }>;
}

const money = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0
});

export default function AdminPage() {
  const { accessToken, hasHydrated } = useRequireAuth({ roles: ["ADMIN"] });
  const queryClient = useQueryClient();
  const [userSearch, setUserSearch] = useState("");
  const [userRole, setUserRole] = useState<"ALL" | "ADMIN" | "INSTRUCTOR" | "STUDENT">("ALL");
  const [userStatus, setUserStatus] = useState<"ALL" | "true" | "false">("ALL");
  const [tenantSearch, setTenantSearch] = useState("");
  const [tenantStatus, setTenantStatus] = useState<"ALL" | "true" | "false">("ALL");
  const [selectedTenantId, setSelectedTenantId] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  const overviewQuery = useQuery({
    queryKey: ["admin", "overview"],
    queryFn: () => apiFetch<OverviewResponse>("/admin/overview", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const tenantsPath = useMemo(() => {
    const params = new URLSearchParams();
    if (tenantSearch.trim()) params.set("search", tenantSearch.trim());
    if (tenantStatus !== "ALL") params.set("isActive", tenantStatus);
    return `/admin/tenants${params.toString() ? `?${params.toString()}` : ""}`;
  }, [tenantSearch, tenantStatus]);

  const usersPath = useMemo(() => {
    const params = new URLSearchParams();
    if (userSearch.trim()) params.set("search", userSearch.trim());
    if (userRole !== "ALL") params.set("role", userRole);
    if (userStatus !== "ALL") params.set("isActive", userStatus);
    return `/admin/users${params.toString() ? `?${params.toString()}` : ""}`;
  }, [userRole, userSearch, userStatus]);

  const tenantsQuery = useQuery({
    queryKey: ["admin", "tenants", tenantSearch, tenantStatus],
    queryFn: () => apiFetch<TenantListItem[]>(tenantsPath, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const tenantDetailQuery = useQuery({
    queryKey: ["admin", "tenant-detail", selectedTenantId],
    queryFn: () => apiFetch<TenantDetail>(`/admin/tenants/${selectedTenantId}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && selectedTenantId)
  });

  const usersQuery = useQuery({
    queryKey: ["admin", "users", userSearch, userRole, userStatus],
    queryFn: () => apiFetch<AdminUser[]>(usersPath, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const userDetailQuery = useQuery({
    queryKey: ["admin", "user-detail", selectedUserId],
    queryFn: () => apiFetch<UserDetailResponse>(`/admin/users/${selectedUserId}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && selectedUserId)
  });

  const coursesQuery = useQuery({
    queryKey: ["admin", "courses"],
    queryFn: () => apiFetch<AdminCourse[]>("/admin/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const paymentsQuery = useQuery({
    queryKey: ["admin", "payments"],
    queryFn: () => apiFetch<AdminPayment[]>("/admin/payments", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const activityQuery = useQuery({
    queryKey: ["admin", "activity"],
    queryFn: () => apiFetch<ActivityResponse>("/admin/activity", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const tenantStatusMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiFetch(`/admin/tenants/${id}/status`, {
        method: "PATCH",
        token: accessToken ?? undefined,
        body: JSON.stringify({ isActive })
      }),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["admin", "overview"] }),
        queryClient.invalidateQueries({ queryKey: ["admin", "tenants"] }),
        queryClient.invalidateQueries({ queryKey: ["admin", "tenant-detail"] })
      ]);
    }
  });

  const userStatusMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiFetch(`/admin/users/${id}/status`, {
        method: "PATCH",
        token: accessToken ?? undefined,
        body: JSON.stringify({ isActive })
      }),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["admin", "users"] }),
        queryClient.invalidateQueries({ queryKey: ["admin", "user-detail"] })
      ]);
    }
  });

  if (!hasHydrated) {
    return <main className="p-8">Loading admin session...</main>;
  }

  return (
    <PageShell
      title="Admin Dashboard"
      description="Platform-wide oversight for tenants, users, courses, payments, and recent operational activity."
      backHref="/dashboard"
      maxWidthClassName="max-w-7xl"
    >
      {overviewQuery.isError ? <StatusBanner variant="error">Failed to load admin overview.</StatusBanner> : null}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-6">
        {[
          { label: "Users", value: overviewQuery.data?.totals.users ?? 0 },
          { label: "Tenants", value: overviewQuery.data?.totals.tenants ?? 0 },
          { label: "Courses", value: overviewQuery.data?.totals.courses ?? 0 },
          { label: "Approved Payments", value: overviewQuery.data?.totals.approvedPayments ?? 0 },
          { label: "Revenue", value: money.format(overviewQuery.data?.totals.approvedRevenue ?? 0) },
          { label: "Unread Notifications", value: overviewQuery.data?.totals.unreadNotifications ?? 0 }
        ].map((item) => (
          <ContentCard key={item.label} className="p-5">
            <p className="text-xs uppercase tracking-[0.2em] text-slate-400">{item.label}</p>
            <p className="mt-3 text-3xl font-semibold text-slate-950">{item.value}</p>
          </ContentCard>
        ))}
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
        <ContentCard className="p-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold text-slate-950">Tenants</h2>
              <p className="text-sm text-slate-500">Search, inspect, and activate/deactivate organizations.</p>
            </div>
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-[minmax(0,1fr)_180px]">
            <input
              value={tenantSearch}
              onChange={(event) => setTenantSearch(event.target.value)}
              placeholder="Search tenant name or invite code"
              className="rounded-xl border border-slate-300 px-4 py-3 text-sm"
            />
            <select
              value={tenantStatus}
              onChange={(event) => setTenantStatus(event.target.value as typeof tenantStatus)}
              className="rounded-xl border border-slate-300 px-4 py-3 text-sm"
            >
              <option value="ALL">All statuses</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </select>
          </div>
          <div className="mt-4 space-y-3">
            {tenantsQuery.data?.length ? (
              tenantsQuery.data.map((tenant) => (
                <button
                  key={tenant.id}
                  type="button"
                  onClick={() => setSelectedTenantId(tenant.id)}
                  className={`w-full rounded-2xl border p-4 text-left transition ${
                    selectedTenantId === tenant.id ? "border-sky-300 bg-sky-50" : "border-slate-200 bg-white hover:border-slate-300"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-950">{tenant.name}</p>
                      <p className="mt-1 text-sm text-slate-500">Owner: {tenant.owner?.fullName ?? "Unassigned"}</p>
                      <p className="mt-2 text-xs text-slate-500">
                        {tenant.usage.usersCount} users • {tenant.usage.coursesCount} courses • {tenant.usage.enrollmentsCount} enrollments
                      </p>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-medium ${tenant.isActive ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`}>
                      {tenant.isActive ? "Active" : "Inactive"}
                    </span>
                  </div>
                </button>
              ))
            ) : tenantsQuery.isLoading ? (
              <StatusBanner>Loading tenants...</StatusBanner>
            ) : (
              <EmptyState title="No tenants found" description="Tenant search will populate here when matching organizations exist." />
            )}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Tenant Detail</h2>
          {tenantDetailQuery.data ? (
            <div className="mt-4 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xl font-semibold text-slate-950">{tenantDetailQuery.data.name}</p>
                  <p className="mt-1 text-sm text-slate-500">Invite Code: {tenantDetailQuery.data.inviteCode}</p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    tenantStatusMutation.mutate({
                      id: tenantDetailQuery.data.id,
                      isActive: !tenantDetailQuery.data.isActive
                    })
                  }
                  disabled={tenantStatusMutation.isPending}
                  className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 disabled:opacity-60"
                >
                  {tenantDetailQuery.data.isActive ? "Deactivate" : "Reactivate"}
                </button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                  <p className="font-medium text-slate-900">Usage</p>
                  <p className="mt-2">{tenantDetailQuery.data.usage.usersCount} users</p>
                  <p>{tenantDetailQuery.data.usage.coursesCount} courses</p>
                  <p>{tenantDetailQuery.data.usage.paymentsCount} payments</p>
                  <p>{money.format(tenantDetailQuery.data.usage.approvedRevenue)} approved revenue</p>
                </div>
                <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                  <p className="font-medium text-slate-900">Owner</p>
                  <p className="mt-2">{tenantDetailQuery.data.owner?.fullName ?? "Unassigned"}</p>
                  <p>{tenantDetailQuery.data.owner?.email ?? "No email"}</p>
                </div>
              </div>
              <div>
                <p className="font-medium text-slate-900">Recent Tenant Activity</p>
                <div className="mt-3 space-y-2">
                  {tenantDetailQuery.data.recentNotifications.length ? (
                    tenantDetailQuery.data.recentNotifications.map((item) => (
                      <div key={item.id} className="rounded-xl border border-slate-200 p-3">
                        <p className="text-sm font-medium text-slate-900">{item.title}</p>
                        <p className="mt-1 text-sm text-slate-600">{item.message}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-slate-500">No tenant activity yet.</p>
                  )}
                </div>
              </div>
            </div>
          ) : tenantDetailQuery.isLoading ? (
            <StatusBanner>Loading tenant detail...</StatusBanner>
          ) : (
            <EmptyState title="Select a tenant" description="Choose a tenant from the list to inspect its users, courses, and activity." />
          )}
        </ContentCard>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Users</h2>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <input
              value={userSearch}
              onChange={(event) => setUserSearch(event.target.value)}
              placeholder="Search name or email"
              className="rounded-xl border border-slate-300 px-4 py-3 text-sm"
            />
            <select
              value={userRole}
              onChange={(event) => setUserRole(event.target.value as typeof userRole)}
              className="rounded-xl border border-slate-300 px-4 py-3 text-sm"
            >
              <option value="ALL">All roles</option>
              <option value="ADMIN">Admin</option>
              <option value="INSTRUCTOR">Instructor</option>
              <option value="STUDENT">Student</option>
            </select>
            <select
              value={userStatus}
              onChange={(event) => setUserStatus(event.target.value as typeof userStatus)}
              className="rounded-xl border border-slate-300 px-4 py-3 text-sm"
            >
              <option value="ALL">All statuses</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </select>
          </div>
          <div className="mt-4 space-y-3">
            {usersQuery.data?.length ? (
              usersQuery.data.map((user) => (
                <button
                  key={user.id}
                  type="button"
                  onClick={() => setSelectedUserId(user.id)}
                  className={`w-full rounded-2xl border p-4 text-left transition ${
                    selectedUserId === user.id ? "border-sky-300 bg-sky-50" : "border-slate-200 bg-white hover:border-slate-300"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-950">{user.fullName}</p>
                      <p className="mt-1 text-sm text-slate-500">{user.email}</p>
                      <p className="mt-2 text-xs text-slate-500">
                        {user.role} • {user.tenant?.name ?? "No tenant"}
                      </p>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-medium ${user.isActive ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`}>
                      {user.isActive ? "Active" : "Inactive"}
                    </span>
                  </div>
                </button>
              ))
            ) : usersQuery.isLoading ? (
              <StatusBanner>Loading users...</StatusBanner>
            ) : (
              <EmptyState title="No users found" description="Adjust the filters to surface users here." />
            )}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">User Detail</h2>
          {userDetailQuery.data ? (
            <div className="mt-4 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xl font-semibold text-slate-950">{userDetailQuery.data.user.fullName}</p>
                  <p className="mt-1 text-sm text-slate-500">{userDetailQuery.data.user.email}</p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    userStatusMutation.mutate({
                      id: userDetailQuery.data.user.id,
                      isActive: !userDetailQuery.data.user.isActive
                    })
                  }
                  disabled={userStatusMutation.isPending}
                  className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 disabled:opacity-60"
                >
                  {userDetailQuery.data.user.isActive ? "Deactivate" : "Reactivate"}
                </button>
              </div>
              <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                <p>Role: {userDetailQuery.data.user.role}</p>
                <p>Tenant: {userDetailQuery.data.user.tenant?.name ?? "No tenant"}</p>
                <p>Payments: {userDetailQuery.data.user._count.payments}</p>
                <p>Enrollments: {userDetailQuery.data.user._count.enrollments}</p>
                <p>Courses: {userDetailQuery.data.user._count.instructorCourses}</p>
              </div>
              <div>
                <p className="font-medium text-slate-900">Recent Payments</p>
                <div className="mt-2 space-y-2">
                  {userDetailQuery.data.recentPayments.length ? (
                    userDetailQuery.data.recentPayments.map((payment) => (
                      <div key={payment.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                        {payment.course.title} • {money.format(payment.amount)} • {payment.status}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-slate-500">No recent payments.</p>
                  )}
                </div>
              </div>
            </div>
          ) : userDetailQuery.isLoading ? (
            <StatusBanner>Loading user detail...</StatusBanner>
          ) : (
            <EmptyState title="Select a user" description="Choose a user from the list to inspect account state and recent activity." />
          )}
        </ContentCard>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-2">
        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Platform Courses</h2>
          <div className="mt-4 space-y-3">
            {coursesQuery.data?.length ? (
              coursesQuery.data.slice(0, 10).map((course) => (
                <div key={course.id} className="rounded-2xl border border-slate-200 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-950">{course.title}</p>
                      <p className="mt-1 text-sm text-slate-500">
                        {course.instructor.fullName} • {course.tenant.name}
                      </p>
                      <p className="mt-2 text-xs text-slate-500">
                        {course._count.enrollments} enrollments • {course._count.reviews} reviews
                      </p>
                    </div>
                    <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700">
                      {course.status}
                    </span>
                  </div>
                </div>
              ))
            ) : coursesQuery.isLoading ? (
              <StatusBanner>Loading courses...</StatusBanner>
            ) : (
              <EmptyState title="No courses yet" description="Course oversight will appear here when courses exist." />
            )}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Platform Payments</h2>
          <div className="mt-4 space-y-3">
            {paymentsQuery.data?.length ? (
              paymentsQuery.data.slice(0, 10).map((payment) => (
                <div key={payment.id} className="rounded-2xl border border-slate-200 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-950">{payment.course.title}</p>
                      <p className="mt-1 text-sm text-slate-500">
                        {payment.user.fullName} • {payment.tenant.name}
                      </p>
                      <p className="mt-2 text-xs text-slate-500">
                        {payment.method.label} • {money.format(payment.amount)}
                      </p>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-medium ${
                      payment.status === "APPROVED"
                        ? "bg-emerald-100 text-emerald-800"
                        : payment.status === "REJECTED"
                          ? "bg-rose-100 text-rose-800"
                          : "bg-amber-100 text-amber-800"
                    }`}>
                      {payment.status}
                    </span>
                  </div>
                </div>
              ))
            ) : paymentsQuery.isLoading ? (
              <StatusBanner>Loading payments...</StatusBanner>
            ) : (
              <EmptyState title="No payments yet" description="Payment oversight will appear here when transactions exist." />
            )}
          </div>
        </ContentCard>
      </div>

      <ContentCard className="mt-8 p-6">
        <h2 className="text-lg font-semibold text-slate-950">Recent Platform Activity</h2>
        {activityQuery.data ? (
          <div className="mt-4 grid gap-4 xl:grid-cols-4">
            <div>
              <p className="text-sm font-medium text-slate-900">Users</p>
              <div className="mt-3 space-y-2">
                {activityQuery.data.recentUsers.map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                    {item.fullName} • {item.role}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-slate-900">Courses</p>
              <div className="mt-3 space-y-2">
                {activityQuery.data.recentCourses.map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                    {item.title} • {item.status}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-slate-900">Payments</p>
              <div className="mt-3 space-y-2">
                {activityQuery.data.recentPayments.map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                    {item.user.fullName} • {item.course.title}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-slate-900">Notifications</p>
              <div className="mt-3 space-y-2">
                {activityQuery.data.recentNotifications.map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                    {item.title}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : activityQuery.isLoading ? (
          <StatusBanner>Loading activity...</StatusBanner>
        ) : (
          <EmptyState title="No recent activity" description="Platform activity will populate here as the system is used." />
        )}
      </ContentCard>
    </PageShell>
  );
}
