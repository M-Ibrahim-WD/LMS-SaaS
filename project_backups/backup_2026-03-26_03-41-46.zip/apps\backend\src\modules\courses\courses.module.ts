import { Module } from "@nestjs/common";
import { CoursesController, CoursesPublicController } from "./controllers/courses.controller";
import { CoursesService } from "./services/courses.service";

@Module({
  controllers: [CoursesController, CoursesPublicController],
  providers: [CoursesService],
  exports: [CoursesService]
})
export class CoursesModule {}
