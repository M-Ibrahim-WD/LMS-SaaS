import { Module } from "@nestjs/common";
import { InstructorController } from "./controllers/instructor.controller";
import { InstructorService } from "./services/instructor.service";
import { UsersModule } from "../users/users.module";

@Module({
  imports: [UsersModule],
  controllers: [InstructorController],
  providers: [InstructorService]
})
export class InstructorModule {}
