import { Controller, Get, UseGuards } from "@nestjs/common";
import { CurrentUser } from "../../../shared/decorators/current-user.decorator";
import { Roles } from "../../../shared/decorators/roles.decorator";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { JwtAuthGuard } from "../../auth/guards/jwt-auth.guard";
import { InstructorService } from "../services/instructor.service";
import { RolesGuard } from "../../../shared/guards/roles.guard";

@Controller("instructor")
@UseGuards(JwtAuthGuard, RolesGuard)
export class InstructorController {
  constructor(private readonly instructorService: InstructorService) {}

  @Roles("INSTRUCTOR")
  @Get("stats")
  getStats(@CurrentUser() user: JwtPayload) {
    return this.instructorService.getStats(user);
  }
}
