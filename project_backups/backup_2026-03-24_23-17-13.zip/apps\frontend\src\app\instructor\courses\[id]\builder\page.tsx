"use client";

import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { FormEvent, useState } from "react";
import { apiFetch } from "../../../../../lib/api/client";
import { BackButton } from "../../../../../components/back-button";
import { useRequireAuth } from "../../../../../hooks/use-require-auth";

interface Lesson {
  id: string;
  title: string;
  content: string;
  type: "VIDEO" | "TEXT" | "FILE";
  order: number;
}

interface Section {
  id: string;
  title: string;
  order: number;
  lessons: Lesson[];
}

interface Course {
  id: string;
  title: string;
  description?: string | null;
  status: "DRAFT" | "PUBLISHED";
  sections: Section[];
}

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer?: string;
  order: number;
}

interface Quiz {
  id: string;
  title: string;
  description?: string | null;
  questions: QuizQuestion[];
}

interface Assignment {
  id: string;
  title: string;
  description?: string | null;
  instructions?: string | null;
}

interface CourseAssessments {
  quizzes: Quiz[];
  assignments: Assignment[];
}

export default function CourseBuilderPage() {
  const params = useParams<{ id: string }>();
  const { accessToken, hasHydrated, isAuthorized } = useRequireAuth({ roles: ["INSTRUCTOR"] });
  const [sectionTitle, setSectionTitle] = useState("");

  const courseQuery = useQuery({
    queryKey: ["course-builder", params.id],
    queryFn: () => apiFetch<Course>(`/courses/${params.id}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && params.id && isAuthorized)
  });

  const assessmentsQuery = useQuery({
    queryKey: ["course-assessments-builder", params.id],
    queryFn: () => apiFetch<CourseAssessments>(`/assessments/courses/${params.id}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && params.id && isAuthorized)
  });

  async function refreshAll() {
    await Promise.all([courseQuery.refetch(), assessmentsQuery.refetch()]);
  }

  async function addSection(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await apiFetch("/sections", {
      method: "POST",
      token: accessToken ?? undefined,
      body: JSON.stringify({
        title: sectionTitle,
        courseId: params.id
      })
    });
    setSectionTitle("");
    await courseQuery.refetch();
  }

  async function addLesson(sectionId: string) {
    const title = window.prompt("Lesson title");
    if (!title) {
      return;
    }
    const type = window.prompt("Type: VIDEO | TEXT | FILE", "TEXT") ?? "TEXT";
    const content = window.prompt("Lesson content or URL", "") ?? "";

    await apiFetch("/lessons", {
      method: "POST",
      token: accessToken ?? undefined,
      body: JSON.stringify({
        sectionId,
        title,
        type,
        content
      })
    });
    await courseQuery.refetch();
  }

  async function addQuiz() {
    const title = window.prompt("Quiz title");
    if (!title) {
      return;
    }

    const description = window.prompt("Quiz description", "") ?? "";
    const questions: Array<{ question: string; options: string[]; correctAnswer: string }> = [];

    while (true) {
      const question = window.prompt(`Question ${questions.length + 1} text`);
      if (!question) {
        break;
      }

      const optionsInput = window.prompt("Options separated by |", "Option A|Option B");
      if (!optionsInput) {
        break;
      }

      const options = optionsInput
        .split("|")
        .map((item) => item.trim())
        .filter(Boolean);

      if (options.length < 2) {
        window.alert("Each quiz question needs at least two options.");
        continue;
      }

      const correctAnswer = window.prompt("Correct answer (must match one option exactly)", options[0]) ?? "";
      if (!options.includes(correctAnswer)) {
        window.alert("Correct answer must exactly match one of the options.");
        continue;
      }

      questions.push({
        question,
        options,
        correctAnswer
      });

      const shouldContinue = window.confirm("Add another question?");
      if (!shouldContinue) {
        break;
      }
    }

    if (questions.length === 0) {
      window.alert("Quiz creation cancelled. At least one question is required.");
      return;
    }

    await apiFetch("/assessments/quizzes", {
      method: "POST",
      token: accessToken ?? undefined,
      body: JSON.stringify({
        courseId: params.id,
        title,
        description,
        questions
      })
    });

    await assessmentsQuery.refetch();
  }

  async function addAssignment() {
    const title = window.prompt("Assignment title");
    if (!title) {
      return;
    }

    const description = window.prompt("Assignment description", "") ?? "";
    const instructions = window.prompt("Assignment instructions", "") ?? "";

    await apiFetch("/assessments/assignments", {
      method: "POST",
      token: accessToken ?? undefined,
      body: JSON.stringify({
        courseId: params.id,
        title,
        description,
        instructions
      })
    });

    await assessmentsQuery.refetch();
  }

  async function updateSection(sectionId: string, currentTitle: string) {
    const title = window.prompt("New section title", currentTitle);
    if (!title) {
      return;
    }

    await apiFetch(`/sections/${sectionId}`, {
      method: "PATCH",
      token: accessToken ?? undefined,
      body: JSON.stringify({ title })
    });
    await courseQuery.refetch();
  }

  async function deleteSection(sectionId: string) {
    await apiFetch(`/sections/${sectionId}`, {
      method: "DELETE",
      token: accessToken ?? undefined
    });
    await courseQuery.refetch();
  }

  async function updateLesson(lesson: Lesson) {
    const title = window.prompt("New lesson title", lesson.title);
    if (!title) {
      return;
    }
    const content = window.prompt("New lesson content", lesson.content);
    if (content === null) {
      return;
    }
    await apiFetch(`/lessons/${lesson.id}`, {
      method: "PATCH",
      token: accessToken ?? undefined,
      body: JSON.stringify({ title, content })
    });
    await courseQuery.refetch();
  }

  async function deleteLesson(lessonId: string) {
    await apiFetch(`/lessons/${lessonId}`, {
      method: "DELETE",
      token: accessToken ?? undefined
    });
    await courseQuery.refetch();
  }

  return (
    <main className="mx-auto max-w-6xl p-8">
      <BackButton fallbackHref="/instructor/courses" />
      <h1 className="text-2xl font-semibold">Course Builder</h1>

      {courseQuery.data ? (
        <div className="mt-4 rounded-lg bg-white p-4 shadow">
          <p className="text-lg font-medium">{courseQuery.data.title}</p>
          <p className="text-sm text-slate-600">{courseQuery.data.description}</p>
          <p className="mt-2 text-sm">
            Status: <span className="font-medium">{courseQuery.data.status}</span>
          </p>
        </div>
      ) : null}

      <form onSubmit={addSection} className="mt-6 flex gap-2">
        <input
          className="w-full rounded border px-3 py-2"
          placeholder="New section title"
          value={sectionTitle}
          onChange={(event) => setSectionTitle(event.target.value)}
          required
        />
        <button className="rounded bg-slate-900 px-4 py-2 text-white">Add Section</button>
      </form>

      <div className="mt-8 flex flex-wrap gap-2">
        <button onClick={() => void addQuiz()} className="rounded border border-slate-300 px-4 py-2 text-sm">
          Add Quiz
        </button>
        <button onClick={() => void addAssignment()} className="rounded border border-slate-300 px-4 py-2 text-sm">
          Add Assignment
        </button>
        <button onClick={() => void refreshAll()} className="rounded border border-slate-300 px-4 py-2 text-sm">
          Refresh
        </button>
      </div>

      <div className="mt-6 space-y-4">
        {courseQuery.data?.sections?.map((section) => (
          <div key={section.id} className="rounded-xl bg-white p-5 shadow">
            <div className="flex items-center justify-between">
              <p className="font-medium">
                {section.order}. {section.title}
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void updateSection(section.id, section.title)}
                  className="rounded border px-3 py-1 text-sm"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => void deleteSection(section.id)}
                  className="rounded border px-3 py-1 text-sm"
                >
                  Delete
                </button>
                <button
                  type="button"
                  onClick={() => void addLesson(section.id)}
                  className="rounded bg-slate-900 px-3 py-1 text-sm text-white"
                >
                  Add Lesson
                </button>
              </div>
            </div>

            <div className="mt-3 space-y-2">
              {section.lessons.map((lesson) => (
                <div key={lesson.id} className="rounded border p-3">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">
                      {lesson.order}. {lesson.title}
                    </p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => void updateLesson(lesson)}
                        className="rounded border px-2 py-1 text-xs"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => void deleteLesson(lesson.id)}
                        className="rounded border px-2 py-1 text-xs"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-slate-600">Type: {lesson.type}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <section className="rounded-xl bg-white p-5 shadow">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Quizzes</h2>
            <span className="text-sm text-slate-500">{assessmentsQuery.data?.quizzes.length ?? 0}</span>
          </div>
          <div className="mt-4 space-y-3">
            {assessmentsQuery.data?.quizzes.length ? (
              assessmentsQuery.data.quizzes.map((quiz) => (
                <div key={quiz.id} className="rounded border border-slate-200 p-4">
                  <p className="font-medium">{quiz.title}</p>
                  {quiz.description ? <p className="mt-1 text-sm text-slate-600">{quiz.description}</p> : null}
                  <div className="mt-3 space-y-2">
                    {quiz.questions.map((question) => (
                      <div key={question.id} className="rounded bg-slate-50 p-3 text-sm">
                        <p className="font-medium">
                          {question.order}. {question.question}
                        </p>
                        <p className="mt-1 text-slate-600">Options: {question.options.join(" | ")}</p>
                        <p className="mt-1 text-xs text-slate-500">Correct: {question.correctAnswer}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-500">No quizzes yet.</p>
            )}
          </div>
        </section>

        <section className="rounded-xl bg-white p-5 shadow">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Assignments</h2>
            <span className="text-sm text-slate-500">{assessmentsQuery.data?.assignments.length ?? 0}</span>
          </div>
          <div className="mt-4 space-y-3">
            {assessmentsQuery.data?.assignments.length ? (
              assessmentsQuery.data.assignments.map((assignment) => (
                <div key={assignment.id} className="rounded border border-slate-200 p-4">
                  <p className="font-medium">{assignment.title}</p>
                  {assignment.description ? (
                    <p className="mt-1 text-sm text-slate-600">{assignment.description}</p>
                  ) : null}
                  {assignment.instructions ? (
                    <p className="mt-2 text-sm text-slate-700">{assignment.instructions}</p>
                  ) : null}
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-500">No assignments yet.</p>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
