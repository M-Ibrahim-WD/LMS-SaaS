﻿import type { PaymentMethodType } from "../../../lib/payments/payment-methods";

export interface Profile {
  id: string;
  email: string;
  fullName: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  tenantId: string | null;
  tenant?: {
    id: string;
    name: string;
  } | null;
  createdAt: string;
}

export interface InviteCodeResponse {
  inviteCode: string;
}

export interface StudentInstructorItem {
  id: string;
  createdAt: string;
  instructor: {
    id: string;
    fullName: string;
    email: string;
    tenant?: {
      id: string;
      name: string;
      inviteCode: string;
    } | null;
  };
}

export interface StudentCourse {
  id: string;
  title: string;
  description?: string | null;
  category?: string | null;
  level: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
  isPaid: boolean;
  price?: number | null;
  status: "DRAFT" | "PUBLISHED";
  instructor?: {
    id: string;
    fullName: string;
  };
  progress?: CourseProgress | null;
}

export interface EnrolledCourse {
  id: string;
  courseId: string;
  createdAt: string;
  course: StudentCourse;
  progress?: CourseProgress | null;
}

export interface CourseProgress {
  totalLessons: number;
  completedLessons: number;
  percentage: number;
  isComplete: boolean;
}

export type StudentTab = "ALL" | "MY" | "INSTRUCTOR";
export type CourseFilter = "ALL" | "FREE" | "PAID";

export interface PaymentMethod {
  id: string;
  type: PaymentMethodType;
  category: "MANUAL" | "ONLINE";
  label: string;
  details: string;
  isActive: boolean;
}

export interface InstructorPayment {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  proof: string;
  proofPreviewUrl?: string;
  proofDownloadUrl?: string;
  proofContentType?: string | null;
  proofFileName?: string | null;
  course: {
    id: string;
    title: string;
    price?: number | null;
  };
  user: {
    id: string;
    fullName: string;
    email: string;
  };
  method: {
    id: string;
    label: string;
    type: PaymentMethodType;
  };
}

export interface StudentDashboardCourse extends StudentCourse {
  description: string;
  instructorId: string;
  instructorName: string;
  isEnrolled: boolean;
  progress: CourseProgress | null;
}
