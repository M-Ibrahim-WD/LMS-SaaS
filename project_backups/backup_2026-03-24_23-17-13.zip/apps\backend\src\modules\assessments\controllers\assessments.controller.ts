import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";
import { CurrentUser } from "../../../shared/decorators/current-user.decorator";
import { RequireTenant } from "../../../shared/decorators/require-tenant.decorator";
import { Roles } from "../../../shared/decorators/roles.decorator";
import { TenantContextGuard } from "../../../shared/guards/tenant-context.guard";
import { RolesGuard } from "../../../shared/guards/roles.guard";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { JwtAuthGuard } from "../../auth/guards/jwt-auth.guard";
import { CreateAssignmentDto } from "../dto/create-assignment.dto";
import { CreateQuizDto } from "../dto/create-quiz.dto";
import { SubmitAssignmentDto } from "../dto/submit-assignment.dto";
import { SubmitQuizDto } from "../dto/submit-quiz.dto";
import { AssessmentsService } from "../services/assessments.service";

@Controller("assessments")
@UseGuards(JwtAuthGuard, TenantContextGuard, RolesGuard)
@RequireTenant()
export class AssessmentsController {
  constructor(private readonly assessmentsService: AssessmentsService) {}

  @Get("courses/:courseId")
  getCourseAssessments(@CurrentUser() user: JwtPayload, @Param("courseId") courseId: string) {
    return this.assessmentsService.getCourseAssessments(user, courseId);
  }

  @Roles("INSTRUCTOR")
  @Post("quizzes")
  createQuiz(@CurrentUser() user: JwtPayload, @Body() dto: CreateQuizDto) {
    return this.assessmentsService.createQuiz(user, dto);
  }

  @Roles("INSTRUCTOR")
  @Post("assignments")
  createAssignment(@CurrentUser() user: JwtPayload, @Body() dto: CreateAssignmentDto) {
    return this.assessmentsService.createAssignment(user, dto);
  }

  @Roles("STUDENT")
  @Post("quizzes/:quizId/submit")
  submitQuiz(
    @CurrentUser() user: JwtPayload,
    @Param("quizId") quizId: string,
    @Body() dto: SubmitQuizDto
  ) {
    return this.assessmentsService.submitQuiz(user, quizId, dto);
  }

  @Roles("STUDENT")
  @Post("assignments/:assignmentId/submit")
  submitAssignment(
    @CurrentUser() user: JwtPayload,
    @Param("assignmentId") assignmentId: string,
    @Body() dto: SubmitAssignmentDto
  ) {
    return this.assessmentsService.submitAssignment(user, assignmentId, dto);
  }
}
