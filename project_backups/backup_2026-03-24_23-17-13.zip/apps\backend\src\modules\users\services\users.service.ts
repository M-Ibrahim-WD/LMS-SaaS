import { ConflictException, Injectable } from "@nestjs/common";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import { UserRole } from "@prisma/client";
import * as bcrypt from "bcrypt";
import { UpdateProfileDto } from "../dto/update-profile.dto";

interface CreateUserInput {
  email: string;
  fullName: string;
  password: string;
  role: UserRole | "INSTRUCTOR" | "STUDENT" | "ADMIN";
  tenantId: string | null;
}

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private readonly userSelect = {
    id: true,
    email: true,
    fullName: true,
    role: true,
    tenantId: true,
    tenant: {
      select: {
        id: true,
        name: true
      }
    },
    createdAt: true,
    updatedAt: true
  };

  findById(id: string, tenantId: string | null) {
    return this.prisma.user.findFirst({
      where: tenantId ? { id, tenantId } : { id },
      select: this.userSelect
    });
  }

  findAuthUserByEmail(email: string) {
    return this.prisma.user.findUnique({
      where: {
        email
      }
    });
  }

  async create(data: CreateUserInput) {
    const password = await bcrypt.hash(data.password, 10);

    try {
      return await this.prisma.user.create({
        data: {
          email: data.email,
          fullName: data.fullName,
          role: data.role as UserRole,
          tenantId: data.tenantId,
          password
        },
        select: this.userSelect
      });
    } catch {
      throw new ConflictException("User with this email already exists");
    }
  }

  getProfile(userId: string, tenantId: string | null) {
    return this.findById(userId, tenantId);
  }

  async updateProfile(userId: string, tenantId: string | null, dto: UpdateProfileDto) {
    const data: { fullName?: string; password?: string } = {};

    if (dto.fullName) {
      data.fullName = dto.fullName;
    }

    if (dto.password) {
      data.password = await bcrypt.hash(dto.password, 10);
    }

    const target = await this.prisma.user.findFirst({
      where: tenantId ? { id: userId, tenantId } : { id: userId },
      select: { id: true }
    });

    if (!target) {
      return null;
    }

    return this.prisma.user.update({
      where: { id: target.id },
      data,
      select: this.userSelect
    });
  }

  async assignTenant(userId: string, tenantId: string) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { tenantId },
      select: this.userSelect
    });
  }
}
