import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { PaymentStatus } from "@prisma/client";
import { StudentAccessService } from "../../../shared/access/student-access.service";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { CreateEnrollmentDto } from "../dto/create-enrollment.dto";

@Injectable()
export class EnrollmentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly studentAccessService: StudentAccessService
  ) {}

  async create(user: JwtPayload, dto: CreateEnrollmentDto) {
    if (user.role !== "STUDENT") {
      throw new ForbiddenException("Only students can enroll");
    }

    const course = await this.studentAccessService.getAccessiblePublishedCourseForStudent(user.sub, dto.courseId, {
      id: true,
      tenantId: true,
      isPaid: true,
      instructorId: true
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    if (course.isPaid) {
      const approvedPayment = await this.prisma.payment.findFirst({
        where: {
          userId: user.sub,
          courseId: course.id,
          tenantId: course.tenantId,
          status: PaymentStatus.APPROVED
        },
        select: { id: true }
      });

      if (!approvedPayment) {
        throw new ForbiddenException("Paid course requires approved payment before enrollment");
      }
    }

    try {
      return await this.prisma.enrollment.create({
        data: {
          userId: user.sub,
          courseId: course.id,
          tenantId: course.tenantId
        }
      });
    } catch {
      throw new ConflictException("Already enrolled");
    }
  }

  myCourses(user: JwtPayload) {
    return this.prisma.enrollment
      .findMany({
      where: {
        userId: user.sub
      },
      orderBy: { createdAt: "desc" },
      include: {
        course: {
          include: {
            instructor: {
              select: {
                id: true,
                fullName: true
              }
            }
          }
        }
      }
      })
      .then(async (enrollments) => {
        if (enrollments.length === 0) {
          return [];
        }

        const courseIds = enrollments.map((item) => item.courseId);
        const [sectionRows, completionCounts] = await Promise.all([
          this.prisma.section.findMany({
            where: {
              courseId: {
                in: courseIds
              }
            },
            select: {
              id: true,
              courseId: true,
              _count: {
                select: {
                  lessons: true
                }
              }
            }
          }),
          this.prisma.lessonCompletion.groupBy({
            by: ["courseId"],
            _count: {
              id: true
            },
            where: {
              userId: user.sub,
              courseId: {
                in: courseIds
              }
            }
          })
        ]);

        const totalLessonsByCourse = new Map<string, number>();
        for (const section of sectionRows) {
          totalLessonsByCourse.set(
            section.courseId,
            (totalLessonsByCourse.get(section.courseId) ?? 0) + section._count.lessons
          );
        }

        const completionCountByCourse = new Map<string, number>(
          completionCounts.map((item) => [item.courseId, item._count.id])
        );

        return enrollments.map((enrollment) => {
          const totalLessons = totalLessonsByCourse.get(enrollment.courseId) ?? 0;
          const completedLessons = completionCountByCourse.get(enrollment.courseId) ?? 0;
          const percentage =
            totalLessons > 0 ? Math.round((Math.min(completedLessons, totalLessons) / totalLessons) * 100) : 0;

          return {
            ...enrollment,
            progress: {
              totalLessons,
              completedLessons,
              percentage,
              isComplete: totalLessons > 0 && completedLessons >= totalLessons
            }
          };
        });
      });
  }

  async isEnrolled(userId: string, courseId: string, tenantId: string) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: {
        userId,
        courseId,
        tenantId
      },
      select: { id: true }
    });

    return Boolean(enrollment);
  }
}
