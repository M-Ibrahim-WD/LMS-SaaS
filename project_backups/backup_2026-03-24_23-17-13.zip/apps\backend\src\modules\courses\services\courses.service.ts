import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { CourseLevel, CourseStatus, Prisma } from "@prisma/client";
import { StudentAccessService } from "../../../shared/access/student-access.service";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { CreateCourseDto } from "../dto/create-course.dto";
import { CoursePricingFilter, CourseQueryDto } from "../dto/course-query.dto";
import { UpdateCourseStatusDto } from "../dto/update-course-status.dto";
import { UpdateCourseDto } from "../dto/update-course.dto";

type CourseProgressSummary = {
  totalLessons: number;
  completedLessons: number;
  percentage: number;
  isComplete: boolean;
};

@Injectable()
export class CoursesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly studentAccessService: StudentAccessService
  ) {}

  private readonly includeTree = {
    sections: {
      orderBy: { order: "asc" as const },
      include: {
        lessons: {
          orderBy: { order: "asc" as const }
        }
      }
    }
  };

  async create(user: JwtPayload, dto: CreateCourseDto) {
    if (!user.tenantId) {
      throw new ForbiddenException("Instructor must belong to a tenant");
    }

    const isPaid = dto.isPaid ?? false;
    const price = isPaid ? dto.price ?? null : null;

    if (isPaid && !price) {
      throw new BadRequestException("Paid course must include a valid price");
    }

    return this.prisma.course.create({
      data: {
        title: dto.title,
        description: dto.description,
        category: dto.category?.trim() || null,
        level: dto.level ?? CourseLevel.BEGINNER,
        isPaid,
        price,
        status: CourseStatus.DRAFT,
        instructorId: user.sub,
        tenantId: user.tenantId
      }
    });
  }

  async update(user: JwtPayload, id: string, dto: UpdateCourseDto) {
    const course = await this.prisma.course.findFirst({
      where: {
        id,
        tenantId: user.tenantId ?? undefined,
        instructorId: user.sub
      },
      select: { id: true }
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    const nextIsPaid = dto.isPaid ?? undefined;
    const data: {
      title?: string;
      description?: string;
      category?: string | null;
      level?: CourseLevel;
      isPaid?: boolean;
      price?: number | null;
    } = { ...dto };

    if (dto.category !== undefined) {
      data.category = dto.category.trim() || null;
    }

    if (nextIsPaid === false) {
      data.price = null;
    }

    if (nextIsPaid === true && (dto.price === undefined || dto.price === null)) {
      throw new BadRequestException("Paid course must include a valid price");
    }

    return this.prisma.course.update({
      where: { id: course.id },
      data
    });
  }

  async updateStatus(user: JwtPayload, id: string, dto: UpdateCourseStatusDto) {
    const course = await this.prisma.course.findFirst({
      where: {
        id,
        tenantId: user.tenantId ?? undefined,
        instructorId: user.sub
      },
      select: { id: true }
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    return this.prisma.course.update({
      where: { id: course.id },
      data: { status: dto.status }
    });
  }

  async getAllByTenant(user: JwtPayload, query: CourseQueryDto) {
    const where = this.buildCourseWhere(user, query);
    const pagination = this.resolvePagination(query);

    if (user.role === "INSTRUCTOR") {
      if (!user.tenantId) {
        return [];
      }

      return this.prisma.course.findMany({
        where,
        skip: pagination.skip,
        take: pagination.take,
        orderBy: { createdAt: "desc" },
        include: {
          instructor: {
            select: {
              id: true,
              fullName: true
            }
          }
        }
      });
    }

    if (user.role === "ADMIN") {
      if (!user.tenantId) {
        return [];
      }

      return this.prisma.course.findMany({
        where,
        skip: pagination.skip,
        take: pagination.take,
        orderBy: { createdAt: "desc" },
        include: {
          instructor: {
            select: {
              id: true,
              fullName: true
            }
          }
        }
      });
    }

    const courses = await this.prisma.course.findMany({
      where,
      skip: pagination.skip,
      take: pagination.take,
      orderBy: [{ instructor: { fullName: "asc" } }, { createdAt: "desc" }],
      include: {
        instructor: {
          select: {
            id: true,
            fullName: true
          }
        }
      }
    });

    return this.attachStudentProgressToCourseList(user.sub, courses);
  }

  async getOne(user: JwtPayload, id: string) {
    if (user.role === "INSTRUCTOR") {
      if (!user.tenantId) {
        throw new NotFoundException("Course not found");
      }

      const instructorCourse = await this.prisma.course.findFirst({
        where: {
          id,
          tenantId: user.tenantId,
          instructorId: user.sub
        },
        include: this.includeTree
      });

      if (!instructorCourse) {
        throw new NotFoundException("Course not found");
      }

      return {
        ...instructorCourse,
        progress: await this.getCourseProgressSummaryForCourse(id, user.sub)
      };
    }

    if (user.role === "ADMIN") {
      if (!user.tenantId) {
        throw new NotFoundException("Course not found");
      }

      const adminCourse = await this.prisma.course.findFirst({
        where: {
          id,
          tenantId: user.tenantId
        },
        include: this.includeTree
      });

      if (!adminCourse) {
        throw new NotFoundException("Course not found");
      }

      return adminCourse;
    }

    await this.ensureStudentCanAccessCourse(user, id);

    const course = await this.prisma.course.findFirst({
      where: {
        id
      },
      include: this.includeTree
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    const completedLessonIds = await this.getCompletedLessonIds(user.sub, id);

    return {
      ...course,
      sections: course.sections.map((section) => ({
        ...section,
        lessons: section.lessons.map((lesson) => ({
          ...lesson,
          isCompleted: completedLessonIds.has(lesson.id)
        }))
      })),
      progress: await this.getCourseProgressSummaryForCourse(id, user.sub)
    };
  }

  async completeLesson(user: JwtPayload, courseId: string, lessonId: string) {
    if (user.role !== "STUDENT") {
      throw new ForbiddenException("Only students can mark lessons complete");
    }

    await this.ensureStudentCanAccessCourse(user, courseId);

    const lesson = await this.prisma.lesson.findFirst({
      where: {
        id: lessonId,
        section: {
          courseId
        }
      },
      select: { id: true }
    });

    if (!lesson) {
      throw new NotFoundException("Lesson not found");
    }

    await this.prisma.lessonCompletion.upsert({
      where: {
        userId_lessonId: {
          userId: user.sub,
          lessonId
        }
      },
      update: {},
      create: {
        userId: user.sub,
        lessonId,
        courseId
      }
    });

    return this.getCourseProgressSummaryForCourse(courseId, user.sub);
  }

  private async ensureStudentCanAccessCourse(user: JwtPayload, courseId: string) {
    const followedCourse = await this.studentAccessService.getAccessiblePublishedCourseForStudent(user.sub, courseId, {
      id: true,
      tenantId: true,
      isPaid: true
    });

    if (!followedCourse) {
      throw new ForbiddenException("Join this instructor first");
    }

    const enrolled = await this.prisma.enrollment.findFirst({
      where: {
        userId: user.sub,
        courseId,
        tenantId: followedCourse.tenantId
      },
      select: { id: true }
    });

    if (!enrolled) {
      if (followedCourse.isPaid) {
        throw new ForbiddenException("You need to complete payment to access this course");
      }

      throw new ForbiddenException("Enroll in this course first");
    }

    return followedCourse;
  }

  private async attachStudentProgressToCourseList<T extends { id: string }>(userId: string, courses: T[]) {
    if (courses.length === 0) {
      return [];
    }

    const courseIds = courses.map((course) => course.id);

    const [enrollments, lessonCounts, completionCounts] = await Promise.all([
      this.prisma.enrollment.findMany({
        where: {
          userId,
          courseId: { in: courseIds }
        },
        select: {
          courseId: true
        }
      }),
      this.prisma.lesson.groupBy({
        by: ["sectionId"],
        _count: {
          id: true
        },
        where: {
          section: {
            courseId: { in: courseIds }
          }
        }
      }),
      this.prisma.lessonCompletion.groupBy({
        by: ["courseId"],
        _count: {
          id: true
        },
        where: {
          userId,
          courseId: { in: courseIds }
        }
      })
    ]);

    const sectionIds = lessonCounts.map((item) => item.sectionId);
    const sectionCourseMap =
      sectionIds.length > 0
        ? await this.prisma.section.findMany({
            where: {
              id: { in: sectionIds }
            },
            select: {
              id: true,
              courseId: true
            }
          })
        : [];

    const totalLessonsByCourse = new Map<string, number>();
    for (const section of sectionCourseMap) {
      const sectionCount = lessonCounts.find((item) => item.sectionId === section.id)?._count.id ?? 0;
      totalLessonsByCourse.set(section.courseId, (totalLessonsByCourse.get(section.courseId) ?? 0) + sectionCount);
    }

    const completionCountByCourse = new Map<string, number>(
      completionCounts.map((item) => [item.courseId, item._count.id])
    );
    const enrolledCourseIds = new Set(enrollments.map((item) => item.courseId));

    return courses.map((course) => ({
      ...course,
      progress: enrolledCourseIds.has(course.id)
        ? this.buildCourseProgress(
            totalLessonsByCourse.get(course.id) ?? 0,
            completionCountByCourse.get(course.id) ?? 0
          )
        : null
    }));
  }

  private async getCompletedLessonIds(userId: string, courseId: string) {
    const completions = await this.prisma.lessonCompletion.findMany({
      where: {
        userId,
        courseId
      },
      select: {
        lessonId: true
      }
    });

    return new Set(completions.map((completion) => completion.lessonId));
  }

  private async getCourseProgressSummaryForCourse(courseId: string, userId: string): Promise<CourseProgressSummary> {
    const [totalLessons, completedLessons] = await Promise.all([
      this.prisma.lesson.count({
        where: {
          section: {
            courseId
          }
        }
      }),
      this.prisma.lessonCompletion.count({
        where: {
          userId,
          courseId
        }
      })
    ]);

    return this.buildCourseProgress(totalLessons, completedLessons);
  }

  private buildCourseProgress(totalLessons: number, completedLessons: number): CourseProgressSummary {
    const percentage =
      totalLessons > 0 ? Math.round((Math.min(completedLessons, totalLessons) / totalLessons) * 100) : 0;

    return {
      totalLessons,
      completedLessons,
      percentage,
      isComplete: totalLessons > 0 && completedLessons >= totalLessons
    };
  }

  private buildCourseWhere(user: JwtPayload, query: CourseQueryDto): Prisma.CourseWhereInput {
    const where: Prisma.CourseWhereInput =
      user.role === "INSTRUCTOR"
        ? {
            tenantId: user.tenantId ?? undefined,
            instructorId: user.sub
          }
        : user.role === "ADMIN"
          ? {
              tenantId: user.tenantId ?? undefined
            }
          : {
              status: CourseStatus.PUBLISHED,
              instructor: this.studentAccessService.getFollowedInstructorWhere(user.sub)
            };

    const search = query.search?.trim();
    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { category: { contains: search, mode: "insensitive" } }
      ];
    }

    if (query.pricing === CoursePricingFilter.FREE) {
      where.isPaid = false;
    }

    if (query.pricing === CoursePricingFilter.PAID) {
      where.isPaid = true;
    }

    if (query.category?.trim()) {
      where.category = { equals: query.category.trim(), mode: "insensitive" };
    }

    if (query.level) {
      where.level = query.level;
    }

    return where;
  }

  private resolvePagination(query: CourseQueryDto) {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 12;

    return {
      skip: (page - 1) * pageSize,
      take: pageSize
    };
  }
}
