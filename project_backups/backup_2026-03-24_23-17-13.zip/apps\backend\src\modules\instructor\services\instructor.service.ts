import { ForbiddenException, Injectable } from "@nestjs/common";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import type { JwtPayload } from "../../../shared/types/auth.types";

@Injectable()
export class InstructorService {
  constructor(private readonly prisma: PrismaService) {}

  async getStats(user: JwtPayload) {
    if (!user.tenantId) {
      throw new ForbiddenException("Instructor is not assigned to a tenant");
    }

    const [joinedStudents, enrolledStudents, revenueAggregate] = await Promise.all([
      this.prisma.user.findMany({
        where: {
          role: "STUDENT",
          tenantId: user.tenantId
        },
        select: {
          id: true
        }
      }),
      this.prisma.enrollment.findMany({
        where: {
          tenantId: user.tenantId,
          course: {
            instructorId: user.sub
          },
          user: {
            role: "STUDENT"
          }
        },
        select: {
          userId: true
        }
      }),
      this.prisma.payment.aggregate({
        where: {
          tenantId: user.tenantId,
          status: "APPROVED",
          course: {
            instructorId: user.sub
          }
        },
        _sum: {
          amount: true
        }
      })
    ]);

    const distinctStudentIds = new Set<string>();

    joinedStudents.forEach((student) => {
      distinctStudentIds.add(student.id);
    });

    enrolledStudents.forEach((enrollment) => {
      distinctStudentIds.add(enrollment.userId);
    });

    return {
      studentsCount: distinctStudentIds.size,
      totalRevenue: revenueAggregate._sum.amount ?? 0
    };
  }
}
