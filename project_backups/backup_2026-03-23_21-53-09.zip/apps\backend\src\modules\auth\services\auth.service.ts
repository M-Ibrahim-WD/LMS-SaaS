import { BadRequestException, Injectable, UnauthorizedException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcrypt";
import { UserRole } from "@prisma/client";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import { LoginDto } from "../dto/login.dto";
import { RegisterDto } from "../dto/register.dto";
import { UsersService } from "../../users/services/users.service";
import { TenantsService } from "../../tenants/services/tenants.service";

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly prisma: PrismaService,
    private readonly tenantsService: TenantsService
  ) {}

  async register(dto: RegisterDto) {
    const fullName = dto.fullName ?? dto.email.split("@")[0];
    const role = dto.role ?? "STUDENT";

    if (role === "INSTRUCTOR") {
      if (!dto.organizationName) {
        throw new BadRequestException("organizationName is required for INSTRUCTOR registration");
      }

      const instructor = await this.usersService.create({
        email: dto.email,
        fullName,
        role: UserRole.INSTRUCTOR,
        tenantId: null,
        password: dto.password
      });

      const tenant = await this.tenantsService.create({
        name: dto.organizationName,
        ownerId: instructor.id
      });

      const updatedInstructor = await this.usersService.assignTenant(instructor.id, tenant.id);
      const token = await this.signToken(
        updatedInstructor.id,
        updatedInstructor.email,
        updatedInstructor.role,
        updatedInstructor.tenantId
      );

      return {
        ...token,
        user: updatedInstructor
      };
    }

    if (role === "STUDENT") {
      const user = await this.usersService.create({
        email: dto.email,
        fullName,
        role: UserRole.STUDENT,
        tenantId: null,
        password: dto.password
      });

      const token = await this.signToken(user.id, user.email, user.role, user.tenantId);
      return {
        ...token,
        user
      };
    }

    if (!dto.tenantId) {
      throw new BadRequestException("tenantId is required for ADMIN registration");
    }

    const tenant = await this.prisma.tenant.findUnique({ where: { id: dto.tenantId } });
    if (!tenant) {
      throw new BadRequestException("Invalid tenantId");
    }

    const user = await this.usersService.create({
      email: dto.email,
      fullName,
      role: UserRole.ADMIN,
      tenantId: tenant.id,
      password: dto.password
    });

    const token = await this.signToken(user.id, user.email, user.role, user.tenantId);
    return {
      ...token,
      user
    };
  }

  async login(dto: LoginDto) {
    const user = await this.usersService.findAuthUserByEmail(dto.email);

    if (!user) {
      throw new UnauthorizedException("Invalid credentials");
    }

    const valid = await bcrypt.compare(dto.password, user.password);
    if (!valid) {
      throw new UnauthorizedException("Invalid credentials");
    }

    const token = await this.signToken(user.id, user.email, user.role, user.tenantId);
    const safeUser = await this.usersService.findById(user.id, user.tenantId);

    return {
      ...token,
      user: safeUser
    };
  }

  me(payload: JwtPayload) {
    return this.usersService.findById(payload.sub, payload.tenantId);
  }

  private async signToken(
    userId: string,
    email: string,
    role: UserRole,
    tenantId: string | null
  ) {
    const payload = { sub: userId, email, role, tenantId };
    return {
      accessToken: await this.jwtService.signAsync(payload),
      tokenType: "Bearer"
    };
  }
}
