"use client";

import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "../../lib/api/client";
import { BackButton } from "../../components/back-button";
import { useAuthStore } from "../../store/auth.store";

interface Course {
  id: string;
  title: string;
  description?: string | null;
  isPaid: boolean;
  price?: number | null;
  status: "DRAFT" | "PUBLISHED";
}

export default function CoursesPage() {
  const accessToken = useAuthStore((state) => state.accessToken);
  const user = useAuthStore((state) => state.user);
  const coursesQuery = useQuery({
    queryKey: ["courses"],
    queryFn: () => apiFetch<Course[]>("/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(accessToken)
  });

  return (
    <main className="mx-auto max-w-5xl p-8">
      <BackButton fallbackHref="/dashboard" />
      <h1 className="text-2xl font-semibold">
        {user?.role === "INSTRUCTOR" ? "My Courses" : "Courses"}
      </h1>

      {user?.role === "INSTRUCTOR" ? (
        <a
          href="/instructor/courses"
          className="mt-3 inline-block rounded bg-slate-900 px-4 py-2 text-white"
        >
          Open Course Manager
        </a>
      ) : null}

      {user?.role === "STUDENT" ? (
        <a href="/my-courses" className="mt-3 inline-block rounded bg-slate-900 px-4 py-2 text-white">
          My Courses
        </a>
      ) : null}

      <div className="mt-6 grid gap-3">
        {coursesQuery.data?.map((course) => (
          <a key={course.id} href={`/courses/${course.id}`} className="rounded-xl bg-white p-4 shadow">
            <p className="font-medium">{course.title}</p>
            <p className="text-sm text-slate-600">{course.description}</p>
            <p className="mt-1 text-xs text-slate-500">
              {course.isPaid ? `Paid - ${course.price?.toFixed(2) ?? "0.00"}` : "Free"}
            </p>
          </a>
        ))}
      </div>
    </main>
  );
}
