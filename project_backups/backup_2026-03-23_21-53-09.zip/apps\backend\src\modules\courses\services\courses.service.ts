import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { CourseStatus } from "@prisma/client";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { CreateCourseDto } from "../dto/create-course.dto";
import { UpdateCourseStatusDto } from "../dto/update-course-status.dto";
import { UpdateCourseDto } from "../dto/update-course.dto";

@Injectable()
export class CoursesService {
  constructor(private readonly prisma: PrismaService) {}

  private readonly includeTree = {
    sections: {
      orderBy: { order: "asc" as const },
      include: {
        lessons: {
          orderBy: { order: "asc" as const }
        }
      }
    }
  };

  async create(user: JwtPayload, dto: CreateCourseDto) {
    if (!user.tenantId) {
      throw new ForbiddenException("Instructor must belong to a tenant");
    }

    const isPaid = dto.isPaid ?? false;
    const price = isPaid ? dto.price ?? null : null;

    if (isPaid && !price) {
      throw new BadRequestException("Paid course must include a valid price");
    }

    return this.prisma.course.create({
      data: {
        title: dto.title,
        description: dto.description,
        isPaid,
        price,
        status: CourseStatus.DRAFT,
        instructorId: user.sub,
        tenantId: user.tenantId
      }
    });
  }

  async update(user: JwtPayload, id: string, dto: UpdateCourseDto) {
    const course = await this.prisma.course.findFirst({
      where: {
        id,
        tenantId: user.tenantId ?? undefined,
        instructorId: user.sub
      },
      select: { id: true }
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    const nextIsPaid = dto.isPaid ?? undefined;
    const data: {
      title?: string;
      description?: string;
      isPaid?: boolean;
      price?: number | null;
    } = { ...dto };

    if (nextIsPaid === false) {
      data.price = null;
    }

    if (nextIsPaid === true && (dto.price === undefined || dto.price === null)) {
      throw new BadRequestException("Paid course must include a valid price");
    }

    return this.prisma.course.update({
      where: { id: course.id },
      data
    });
  }

  async updateStatus(user: JwtPayload, id: string, dto: UpdateCourseStatusDto) {
    const course = await this.prisma.course.findFirst({
      where: {
        id,
        tenantId: user.tenantId ?? undefined,
        instructorId: user.sub
      },
      select: { id: true }
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    return this.prisma.course.update({
      where: { id: course.id },
      data: { status: dto.status }
    });
  }

  getAllByTenant(user: JwtPayload) {
    if (!user.tenantId) {
      return [];
    }

    return this.prisma.course.findMany({
      where: {
        tenantId: user.tenantId,
        ...(user.role === "INSTRUCTOR"
          ? { instructorId: user.sub }
          : { status: CourseStatus.PUBLISHED })
      },
      orderBy: { createdAt: "desc" }
    });
  }

  async getOne(user: JwtPayload, id: string) {
    if (!user.tenantId) {
      throw new NotFoundException("Course not found");
    }

    if (user.role === "INSTRUCTOR") {
      const instructorCourse = await this.prisma.course.findFirst({
        where: {
          id,
          tenantId: user.tenantId,
          instructorId: user.sub
        },
        include: this.includeTree
      });

      if (!instructorCourse) {
        throw new NotFoundException("Course not found");
      }

      return instructorCourse;
    }

    const enrolled = await this.prisma.enrollment.findFirst({
      where: {
        userId: user.sub,
        courseId: id,
        tenantId: user.tenantId
      },
      select: { id: true }
    });

    if (!enrolled) {
      const targetCourse = await this.prisma.course.findFirst({
        where: {
          id,
          tenantId: user.tenantId
        },
        select: {
          id: true,
          isPaid: true
        }
      });

      if (targetCourse?.isPaid) {
        throw new ForbiddenException("You need to complete payment to access this course");
      }

      throw new ForbiddenException("Enroll in this course first");
    }

    const course = await this.prisma.course.findFirst({
      where: {
        id,
        tenantId: user.tenantId
      },
      include: this.includeTree
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    return course;
  }
}
