import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { CourseStatus, PaymentStatus } from "@prisma/client";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import type { JwtPayload } from "../../../shared/types/auth.types";
import { CreateEnrollmentDto } from "../dto/create-enrollment.dto";

@Injectable()
export class EnrollmentsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(user: JwtPayload, dto: CreateEnrollmentDto) {
    if (user.role !== "STUDENT") {
      throw new ForbiddenException("Only students can enroll");
    }

    if (!user.tenantId) {
      throw new BadRequestException("Student must join a tenant first");
    }

    const course = await this.prisma.course.findFirst({
      where: {
        id: dto.courseId,
        tenantId: user.tenantId,
        status: CourseStatus.PUBLISHED
      },
      select: { id: true, tenantId: true, isPaid: true }
    });

    if (!course) {
      throw new NotFoundException("Course not found");
    }

    if (course.isPaid) {
      const approvedPayment = await this.prisma.payment.findFirst({
        where: {
          userId: user.sub,
          courseId: course.id,
          tenantId: user.tenantId,
          status: PaymentStatus.APPROVED
        },
        select: { id: true }
      });

      if (!approvedPayment) {
        throw new ForbiddenException("Paid course requires approved payment before enrollment");
      }
    }

    try {
      return await this.prisma.enrollment.create({
        data: {
          userId: user.sub,
          courseId: course.id,
          tenantId: course.tenantId
        }
      });
    } catch {
      throw new ConflictException("Already enrolled");
    }
  }

  myCourses(user: JwtPayload) {
    if (!user.tenantId) {
      return [];
    }

    return this.prisma.enrollment.findMany({
      where: {
        userId: user.sub,
        tenantId: user.tenantId
      },
      orderBy: { createdAt: "desc" },
      include: {
        course: true
      }
    });
  }

  async isEnrolled(userId: string, courseId: string, tenantId: string) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: {
        userId,
        courseId,
        tenantId
      },
      select: { id: true }
    });

    return Boolean(enrollment);
  }
}
