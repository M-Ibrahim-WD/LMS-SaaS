"use client";

import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { apiFetch } from "../../lib/api/client";
import { BackButton } from "../../components/back-button";
import { useAuthStore } from "../../store/auth.store";

interface Course {
  id: string;
  title: string;
  description?: string | null;
  status: "DRAFT" | "PUBLISHED";
  instructor?: {
    id: string;
    fullName: string;
  };
}

interface Enrollment {
  id: string;
  courseId: string;
  createdAt: string;
  course: Course;
}

export default function MyCoursesPage() {
  const router = useRouter();
  const accessToken = useAuthStore((state) => state.accessToken);
  const user = useAuthStore((state) => state.user);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);
  const isStudent = user?.role === "STUDENT";

  useEffect(() => {
    if (!hasHydrated) {
      return;
    }

    if (!accessToken) {
      router.replace("/login");
      return;
    }

    if (user && !user.tenantId) {
      router.replace("/join-tenant");
      return;
    }
  }, [accessToken, hasHydrated, router, user]);

  const myCoursesQuery = useQuery({
    queryKey: ["enrollments", "my-courses"],
    queryFn: () => apiFetch<Enrollment[]>("/enrollments/my-courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && isStudent)
  });

  if (!hasHydrated) {
    return <main className="p-8">Loading session...</main>;
  }

  return (
    <main className="mx-auto max-w-5xl p-8">
      <BackButton fallbackHref="/dashboard" />
      <h1 className="text-2xl font-semibold">My Courses</h1>
      <p className="mt-2 text-sm text-slate-600">Courses you enrolled in will appear here.</p>

      {user && !isStudent ? (
        <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-sm text-slate-700">This page is currently for student enrollments.</p>
          <a href="/courses" className="mt-3 inline-block rounded bg-slate-900 px-4 py-2 text-sm text-white">
            Browse Courses
          </a>
        </div>
      ) : null}

      {myCoursesQuery.isLoading ? <p className="mt-6">Loading courses...</p> : null}
      {myCoursesQuery.isError ? (
        <p className="mt-6 text-red-600">Failed to load your courses. Please try again.</p>
      ) : null}

      {myCoursesQuery.data && myCoursesQuery.data.length === 0 ? (
        <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-sm text-slate-700">You are not enrolled in any course yet.</p>
          <a href="/courses" className="mt-3 inline-block rounded bg-slate-900 px-4 py-2 text-sm text-white">
            Browse Courses
          </a>
        </div>
      ) : null}

      <div className="mt-6 grid gap-3">
        {myCoursesQuery.data?.map((enrollment) => (
          <a
            key={enrollment.id}
            href={`/courses/${enrollment.course.id}`}
            className="rounded-xl bg-white p-4 shadow"
          >
            <p className="font-medium">{enrollment.course.title}</p>
            <p className="text-sm text-slate-600">{enrollment.course.description}</p>
            {enrollment.course.instructor ? (
              <p className="mt-1 text-xs text-slate-500">{enrollment.course.instructor.fullName}</p>
            ) : null}
          </a>
        ))}
      </div>
    </main>
  );
}
