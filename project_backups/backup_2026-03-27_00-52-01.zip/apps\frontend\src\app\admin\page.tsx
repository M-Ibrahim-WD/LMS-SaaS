"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ContentCard } from "../../components/content-card";
import { EmptyState } from "../../components/empty-state";
import { PageShell } from "../../components/page-shell";
import { StatusBanner } from "../../components/status-banner";
import { useRequireAuth } from "../../hooks/use-require-auth";
import { apiFetch } from "../../lib/api/client";

type Plan = {
  id: string;
  code: string;
  name: string;
  description?: string | null;
  monthlyPrice: number;
  yearlyPrice: number;
  maxCourses: number;
  maxSectionsPerCourse: number;
  maxLessonsPerSection: number;
  canPublishCourses: boolean;
  canCreatePaidCourses: boolean;
  maxStudentsTotal: number;
  maxStudentsPerCourse: number;
  canUseQuizzes: boolean;
  canUseAssignments: boolean;
  canIssueCertificates: boolean;
  canUseAnalytics: boolean;
  canUseReviews: boolean;
  maxStorageMb: number;
  canUploadThumbnails: boolean;
  canUploadProfileImage: boolean;
  canUseManualPayments: boolean;
  hasAdvancedAnalytics: boolean;
  hasOnlinePayments: boolean;
  maxAdminUsers: number;
  maxInstructorUsers: number;
  isActive: boolean;
  isCore?: boolean;
  isArchived?: boolean;
  _count?: { tenants: number; subscriptions: number };
};

type TenantSubscriptionInfo = {
  currentSubscription: {
    id: string;
    billingPeriod: "MONTHLY" | "YEARLY";
    state: "TRIAL" | "ACTIVE" | "EXPIRED" | "CANCELED";
    isTrial: boolean;
    endsAt: string;
    adminActivated: boolean;
    plan: Pick<Plan, "id" | "name" | "code">;
  } | null;
  latestSubscription: {
    id: string;
    billingPeriod: "MONTHLY" | "YEARLY";
    state: "TRIAL" | "ACTIVE" | "EXPIRED" | "CANCELED";
    isTrial: boolean;
    endsAt: string;
    plan: Pick<Plan, "id" | "name" | "code">;
  } | null;
  trialRules: {
    maxCourses: number;
    maxSectionsPerCourse: number;
    maxLessonsPerSection: number;
    maxStudentsTotal: number;
  };
  daysRemaining: number;
  freezeCreation: boolean;
};

type Tenant = {
  id: string;
  name: string;
  inviteCode: string;
  isActive: boolean;
  owner?: { fullName: string; email: string } | null;
  plan?: Plan | null;
  subscription?: TenantSubscriptionInfo;
  usage: {
    usersCount: number;
    coursesCount: number;
    paymentsCount: number;
    enrollmentsCount: number;
    approvedRevenue?: number;
    studentsCount?: number;
    instructorsCount?: number;
    adminsCount?: number;
    storageUsedMb?: number;
  };
  recentNotifications?: Array<{ id: string; title: string; message: string }>;
};

type AdminUser = {
  id: string;
  fullName: string;
  email: string;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT";
  isActive: boolean;
  tenant?: { name: string } | null;
  _count: { payments?: number; enrollments: number; instructorCourses: number };
};

type Overview = {
  totals: {
    users: number;
    tenants: number;
    plans: number;
    courses: number;
    approvedPayments: number;
    approvedRevenue: number;
    unreadNotifications: number;
  };
};

type PlanForm = {
  code: string;
  name: string;
  description: string;
  monthlyPrice: string;
  yearlyPrice: string;
  maxCourses: string;
  maxSectionsPerCourse: string;
  maxLessonsPerSection: string;
  maxStudentsTotal: string;
  maxStudentsPerCourse: string;
  maxStorageMb: string;
  canPublishCourses: boolean;
  canCreatePaidCourses: boolean;
  canUseQuizzes: boolean;
  canUseAssignments: boolean;
  canIssueCertificates: boolean;
  canUseAnalytics: boolean;
  canUseReviews: boolean;
  canUploadThumbnails: boolean;
  canUploadProfileImage: boolean;
  canUseManualPayments: boolean;
  hasAdvancedAnalytics: boolean;
  hasOnlinePayments: boolean;
  maxAdminUsers: string;
  maxInstructorUsers: string;
  isActive: boolean;
};

const defaultPlanForm: PlanForm = {
  code: "",
  name: "",
  description: "",
  monthlyPrice: "19",
  yearlyPrice: "190",
  maxCourses: "10",
  maxSectionsPerCourse: "10",
  maxLessonsPerSection: "20",
  maxStudentsTotal: "200",
  maxStudentsPerCourse: "200",
  maxStorageMb: "512",
  canPublishCourses: true,
  canCreatePaidCourses: true,
  canUseQuizzes: true,
  canUseAssignments: true,
  canIssueCertificates: true,
  canUseAnalytics: false,
  canUseReviews: true,
  canUploadThumbnails: true,
  canUploadProfileImage: true,
  canUseManualPayments: true,
  hasAdvancedAnalytics: false,
  hasOnlinePayments: false,
  maxAdminUsers: "3",
  maxInstructorUsers: "1",
  isActive: true
};

const money = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0
});

export default function AdminPage() {
  const { accessToken, hasHydrated } = useRequireAuth({ roles: ["ADMIN"] });
  const queryClient = useQueryClient();
  const [tenantSearch, setTenantSearch] = useState("");
  const [tenantStatus, setTenantStatus] = useState<"ALL" | "true" | "false">("ALL");
  const [userSearch, setUserSearch] = useState("");
  const [userRole, setUserRole] = useState<"ALL" | "ADMIN" | "INSTRUCTOR" | "STUDENT">("ALL");
  const [userStatus, setUserStatus] = useState<"ALL" | "true" | "false">("ALL");
  const [selectedTenantId, setSelectedTenantId] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [tenantPlanId, setTenantPlanId] = useState<string>("");
  const [tenantBillingPeriod, setTenantBillingPeriod] = useState<"MONTHLY" | "YEARLY">("MONTHLY");
  const [planForm, setPlanForm] = useState<PlanForm>(defaultPlanForm);
  const [message, setMessage] = useState<string | null>(null);

  const tenantsPath = useMemo(() => {
    const params = new URLSearchParams();
    if (tenantSearch.trim()) params.set("search", tenantSearch.trim());
    if (tenantStatus !== "ALL") params.set("isActive", tenantStatus);
    return `/admin/tenants${params.toString() ? `?${params.toString()}` : ""}`;
  }, [tenantSearch, tenantStatus]);

  const usersPath = useMemo(() => {
    const params = new URLSearchParams();
    if (userSearch.trim()) params.set("search", userSearch.trim());
    if (userRole !== "ALL") params.set("role", userRole);
    if (userStatus !== "ALL") params.set("isActive", userStatus);
    return `/admin/users${params.toString() ? `?${params.toString()}` : ""}`;
  }, [userSearch, userRole, userStatus]);

  const refresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["admin"] }),
      queryClient.invalidateQueries({ queryKey: ["admin", "tenant-detail"] }),
      queryClient.invalidateQueries({ queryKey: ["admin", "user-detail"] })
    ]);
  };

  const overviewQuery = useQuery({
    queryKey: ["admin", "overview"],
    queryFn: () => apiFetch<Overview>("/admin/overview", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const plansQuery = useQuery({
    queryKey: ["admin", "plans"],
    queryFn: () => apiFetch<Plan[]>("/admin/plans", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const tenantsQuery = useQuery({
    queryKey: ["admin", "tenants", tenantSearch, tenantStatus],
    queryFn: () => apiFetch<Tenant[]>(tenantsPath, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const tenantDetailQuery = useQuery({
    queryKey: ["admin", "tenant-detail", selectedTenantId],
    queryFn: () => apiFetch<Tenant>(`/admin/tenants/${selectedTenantId}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && selectedTenantId)
  });

  const usersQuery = useQuery({
    queryKey: ["admin", "users", userSearch, userRole, userStatus],
    queryFn: () => apiFetch<AdminUser[]>(usersPath, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const userDetailQuery = useQuery({
    queryKey: ["admin", "user-detail", selectedUserId],
    queryFn: () => apiFetch<{ user: AdminUser; recentPayments: Array<{ id: string; amount: number; status: string; course: { title: string } }> }>(`/admin/users/${selectedUserId}`, { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken && selectedUserId)
  });

  const coursesQuery = useQuery({
    queryKey: ["admin", "courses"],
    queryFn: () => apiFetch<Array<{ id: string; title: string; status: string; tenant: { name: string }; instructor: { fullName: string }; _count: { enrollments: number; reviews: number } }>>("/admin/courses", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const paymentsQuery = useQuery({
    queryKey: ["admin", "payments"],
    queryFn: () => apiFetch<Array<{ id: string; status: string; amount: number; tenant: { name: string }; user: { fullName: string }; course: { title: string }; method: { label: string } }>>("/admin/payments", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  const activityQuery = useQuery({
    queryKey: ["admin", "activity"],
    queryFn: () => apiFetch<{ recentUsers: Array<{ id: string; fullName: string; role: string }>; recentCourses: Array<{ id: string; title: string; status: string }>; recentPayments: Array<{ id: string; user: { fullName: string }; course: { title: string } }>; recentNotifications: Array<{ id: string; title: string }> }>("/admin/activity", { token: accessToken ?? undefined }),
    enabled: Boolean(hasHydrated && accessToken)
  });

  useEffect(() => {
    if (!tenantDetailQuery.data) {
      return;
    }

    setTenantPlanId(
      tenantDetailQuery.data.subscription?.currentSubscription?.plan.id ??
        tenantDetailQuery.data.subscription?.latestSubscription?.plan.id ??
        tenantDetailQuery.data.plan?.id ??
        ""
    );
    setTenantBillingPeriod(
      tenantDetailQuery.data.subscription?.currentSubscription?.billingPeriod ??
        tenantDetailQuery.data.subscription?.latestSubscription?.billingPeriod ??
        "MONTHLY"
    );
  }, [tenantDetailQuery.data]);

  const tenantStatusMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiFetch(`/admin/tenants/${id}/status`, {
        method: "PATCH",
        token: accessToken ?? undefined,
        body: JSON.stringify({ isActive })
      }),
    onSuccess: refresh
  });

  const userStatusMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiFetch(`/admin/users/${id}/status`, {
        method: "PATCH",
        token: accessToken ?? undefined,
        body: JSON.stringify({ isActive })
      }),
    onSuccess: refresh
  });

  const archivePlanMutation = useMutation({
    mutationFn: (planId: string) =>
      apiFetch(`/admin/plans/${planId}/archive`, {
        method: "PATCH",
        token: accessToken ?? undefined
      }),
    onSuccess: async () => {
      setMessage("Plan archived successfully.");
      await refresh();
    },
    onError: (error) => setMessage(error instanceof Error ? error.message : "Failed to archive plan.")
  });

  const upsertTenantSubscriptionMutation = useMutation({
    mutationFn: ({ tenantId, planId, billingPeriod, isTrial }: { tenantId: string; planId: string; billingPeriod: "MONTHLY" | "YEARLY"; isTrial?: boolean }) =>
      apiFetch(`/subscription/tenants/${tenantId}`, {
        method: "POST",
        token: accessToken ?? undefined,
        body: JSON.stringify({ planId, billingPeriod, isTrial })
      }),
    onSuccess: async () => {
      setMessage("Tenant subscription updated.");
      await refresh();
    },
    onError: (error) => setMessage(error instanceof Error ? error.message : "Failed to update tenant subscription.")
  });

  const updateTenantSubscriptionMutation = useMutation({
    mutationFn: ({
      tenantId,
      billingPeriod,
      markCanceled,
      restartTrial
    }: {
      tenantId: string;
      billingPeriod?: "MONTHLY" | "YEARLY";
      markCanceled?: boolean;
      restartTrial?: boolean;
    }) =>
      apiFetch(`/subscription/tenants/${tenantId}`, {
        method: "PATCH",
        token: accessToken ?? undefined,
        body: JSON.stringify({ billingPeriod, markCanceled, restartTrial })
      }),
    onSuccess: async () => {
      setMessage("Tenant subscription action completed.");
      await refresh();
    },
    onError: (error) => setMessage(error instanceof Error ? error.message : "Failed to update tenant subscription.")
  });

  const createPlanMutation = useMutation({
    mutationFn: (payload: PlanForm) =>
      apiFetch("/admin/plans", {
        method: "POST",
        token: accessToken ?? undefined,
        body: JSON.stringify({
          ...payload,
          monthlyPrice: Number(payload.monthlyPrice),
          yearlyPrice: Number(payload.yearlyPrice),
          maxCourses: Number(payload.maxCourses),
          maxSectionsPerCourse: Number(payload.maxSectionsPerCourse),
          maxLessonsPerSection: Number(payload.maxLessonsPerSection),
          maxStudentsTotal: Number(payload.maxStudentsTotal),
          maxStudentsPerCourse: Number(payload.maxStudentsPerCourse),
          maxStorageMb: Number(payload.maxStorageMb),
          maxAdminUsers: Number(payload.maxAdminUsers),
          maxInstructorUsers: Number(payload.maxInstructorUsers)
        })
      }),
    onSuccess: async () => {
      setMessage("Plan created successfully.");
      setPlanForm(defaultPlanForm);
      setSelectedPlanId(null);
      await refresh();
    },
    onError: (error) => setMessage(error instanceof Error ? error.message : "Failed to create plan.")
  });

  const updatePlanMutation = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: PlanForm }) =>
      apiFetch(`/admin/plans/${id}`, {
        method: "PATCH",
        token: accessToken ?? undefined,
        body: JSON.stringify({
          ...payload,
          monthlyPrice: Number(payload.monthlyPrice),
          yearlyPrice: Number(payload.yearlyPrice),
          maxCourses: Number(payload.maxCourses),
          maxSectionsPerCourse: Number(payload.maxSectionsPerCourse),
          maxLessonsPerSection: Number(payload.maxLessonsPerSection),
          maxStudentsTotal: Number(payload.maxStudentsTotal),
          maxStudentsPerCourse: Number(payload.maxStudentsPerCourse),
          maxStorageMb: Number(payload.maxStorageMb),
          maxAdminUsers: Number(payload.maxAdminUsers),
          maxInstructorUsers: Number(payload.maxInstructorUsers)
        })
      }),
    onSuccess: async () => {
      setMessage("Plan updated successfully.");
      setPlanForm(defaultPlanForm);
      setSelectedPlanId(null);
      await refresh();
    },
    onError: (error) => setMessage(error instanceof Error ? error.message : "Failed to update plan.")
  });

  const beginEditPlan = (plan: Plan) => {
    setSelectedPlanId(plan.id);
    setPlanForm({
      code: plan.code,
      name: plan.name,
      description: plan.description ?? "",
      monthlyPrice: String(plan.monthlyPrice),
      yearlyPrice: String(plan.yearlyPrice),
      maxCourses: String(plan.maxCourses),
      maxSectionsPerCourse: String(plan.maxSectionsPerCourse),
      maxLessonsPerSection: String(plan.maxLessonsPerSection),
      maxStudentsTotal: String(plan.maxStudentsTotal),
      maxStudentsPerCourse: String(plan.maxStudentsPerCourse),
      maxStorageMb: String(plan.maxStorageMb),
      canPublishCourses: plan.canPublishCourses,
      canCreatePaidCourses: plan.canCreatePaidCourses,
      canUseQuizzes: plan.canUseQuizzes,
      canUseAssignments: plan.canUseAssignments,
      canIssueCertificates: plan.canIssueCertificates,
      canUseAnalytics: plan.canUseAnalytics,
      canUseReviews: plan.canUseReviews,
      canUploadThumbnails: plan.canUploadThumbnails,
      canUploadProfileImage: plan.canUploadProfileImage,
      canUseManualPayments: plan.canUseManualPayments,
      hasAdvancedAnalytics: plan.hasAdvancedAnalytics,
      hasOnlinePayments: plan.hasOnlinePayments,
      maxAdminUsers: String(plan.maxAdminUsers),
      maxInstructorUsers: String(plan.maxInstructorUsers),
      isActive: plan.isActive
    });
    setMessage(null);
  };

  const submitPlan = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (selectedPlanId) {
      updatePlanMutation.mutate({ id: selectedPlanId, payload: planForm });
      return;
    }
    createPlanMutation.mutate(planForm);
  };

  if (!hasHydrated) {
    return <main className="p-8">Loading admin session...</main>;
  }

  return (
    <PageShell
      title="Admin Dashboard"
      description="Full platform control for plans, tenants, users, courses, payments, and operational activity."
      backHref="/dashboard"
      maxWidthClassName="max-w-7xl"
    >
      {overviewQuery.error instanceof Error ? <StatusBanner variant="error">{overviewQuery.error.message}</StatusBanner> : null}
      {message ? <StatusBanner>{message}</StatusBanner> : null}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-7">
        {[
          ["Users", overviewQuery.data?.totals.users ?? 0],
          ["Tenants", overviewQuery.data?.totals.tenants ?? 0],
          ["Plans", overviewQuery.data?.totals.plans ?? 0],
          ["Courses", overviewQuery.data?.totals.courses ?? 0],
          ["Approved Payments", overviewQuery.data?.totals.approvedPayments ?? 0],
          ["Revenue", money.format(overviewQuery.data?.totals.approvedRevenue ?? 0)],
          ["Unread Notifications", overviewQuery.data?.totals.unreadNotifications ?? 0]
        ].map(([label, value]) => (
          <ContentCard key={String(label)} className="p-5">
            <p className="text-xs uppercase tracking-[0.2em] text-slate-400">{label}</p>
            <p className="mt-3 text-3xl font-semibold text-slate-950">{value}</p>
          </ContentCard>
        ))}
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-2">
        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Plans</h2>
          <div className="mt-4 space-y-3">
            {plansQuery.data?.length ? plansQuery.data.map((plan) => (
              <div key={plan.id} className="rounded-2xl border border-slate-200 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold text-slate-950">{plan.name} <span className="text-xs uppercase tracking-[0.2em] text-slate-400">{plan.code}</span></p>
                    <p className="mt-1 text-sm text-slate-500">{plan.description || "No description provided."}</p>
                    <p className="mt-2 text-xs text-slate-500">
                      {money.format(plan.monthlyPrice)}/mo | {money.format(plan.yearlyPrice)}/yr | {plan.maxCourses} courses | {plan.maxStudentsTotal} students | {plan.maxStorageMb} MB
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {plan._count?.tenants ?? 0} tenants | {plan._count?.subscriptions ?? 0} subscription records {plan.isArchived ? "| Archived" : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full px-3 py-1 text-xs font-medium ${plan.isActive ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`}>{plan.isActive ? "Active" : "Inactive"}</span>
                    <button type="button" onClick={() => beginEditPlan(plan)} className="rounded-full border border-slate-300 px-3 py-1 text-xs font-medium text-slate-700">Edit</button>
                    {!plan.isArchived ? (
                      <button type="button" onClick={() => archivePlanMutation.mutate(plan.id)} className="rounded-full border border-amber-300 px-3 py-1 text-xs font-medium text-amber-700">
                        Archive
                      </button>
                    ) : null}
                  </div>
                </div>
              </div>
            )) : plansQuery.isLoading ? <StatusBanner>Loading plans...</StatusBanner> : <EmptyState title="No plans yet" description="Create your first SaaS plan to start controlling tenant limits." />}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">{selectedPlanId ? "Edit Plan" : "Create Plan"}</h2>
          <form onSubmit={submitPlan} className="mt-4 grid gap-3">
            <div className="grid gap-3 md:grid-cols-2">
              <input value={planForm.code} onChange={(event) => setPlanForm((c) => ({ ...c, code: event.target.value }))} placeholder="Plan code" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" required />
              <input value={planForm.name} onChange={(event) => setPlanForm((c) => ({ ...c, name: event.target.value }))} placeholder="Plan name" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" required />
            </div>
            <textarea value={planForm.description} onChange={(event) => setPlanForm((c) => ({ ...c, description: event.target.value }))} placeholder="Description" className="min-h-24 rounded-xl border border-slate-300 px-4 py-3 text-sm" />
            <div className="grid gap-3 md:grid-cols-4">
              <input type="number" min={0} value={planForm.monthlyPrice} onChange={(event) => setPlanForm((c) => ({ ...c, monthlyPrice: event.target.value }))} placeholder="Monthly price" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={0} value={planForm.yearlyPrice} onChange={(event) => setPlanForm((c) => ({ ...c, yearlyPrice: event.target.value }))} placeholder="Yearly price" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxCourses} onChange={(event) => setPlanForm((c) => ({ ...c, maxCourses: event.target.value }))} className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxStorageMb} onChange={(event) => setPlanForm((c) => ({ ...c, maxStorageMb: event.target.value }))} className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
            </div>
            <div className="grid gap-3 md:grid-cols-4">
              <input type="number" min={1} value={planForm.maxSectionsPerCourse} onChange={(event) => setPlanForm((c) => ({ ...c, maxSectionsPerCourse: event.target.value }))} placeholder="Sections / course" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxLessonsPerSection} onChange={(event) => setPlanForm((c) => ({ ...c, maxLessonsPerSection: event.target.value }))} placeholder="Lessons / section" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxStudentsTotal} onChange={(event) => setPlanForm((c) => ({ ...c, maxStudentsTotal: event.target.value }))} placeholder="Students total" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxStudentsPerCourse} onChange={(event) => setPlanForm((c) => ({ ...c, maxStudentsPerCourse: event.target.value }))} placeholder="Students / course" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxAdminUsers} onChange={(event) => setPlanForm((c) => ({ ...c, maxAdminUsers: event.target.value }))} placeholder="Admin users" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
              <input type="number" min={1} value={planForm.maxInstructorUsers} onChange={(event) => setPlanForm((c) => ({ ...c, maxInstructorUsers: event.target.value }))} placeholder="Instructor users" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
            </div>
            <div className="grid gap-2 sm:grid-cols-3">
              {[
                ["canPublishCourses", "Publish courses"],
                ["canCreatePaidCourses", "Paid courses"],
                ["canUseQuizzes", "Quizzes"],
                ["canUseAssignments", "Assignments"],
                ["canIssueCertificates", "Certificates"],
                ["canUseAnalytics", "Analytics"],
                ["canUseReviews", "Reviews"],
                ["canUploadThumbnails", "Thumbnails"],
                ["canUploadProfileImage", "Profile images"],
                ["canUseManualPayments", "Manual payments"],
                ["hasAdvancedAnalytics", "Advanced analytics"],
                ["hasOnlinePayments", "Online payments"],
                ["isActive", "Plan active"]
              ].map(([key, label]) => (
                <label key={key} className="flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700">
                  <input type="checkbox" checked={planForm[key as keyof PlanForm] as boolean} onChange={(event) => setPlanForm((c) => ({ ...c, [key]: event.target.checked }))} />
                  {label}
                </label>
              ))}
            </div>
            <div className="flex gap-3">
              <button type="submit" className="rounded-full bg-slate-950 px-5 py-2 text-sm font-medium text-white">{selectedPlanId ? "Update Plan" : "Create Plan"}</button>
              {selectedPlanId ? <button type="button" onClick={() => { setSelectedPlanId(null); setPlanForm(defaultPlanForm); }} className="rounded-full border border-slate-300 px-5 py-2 text-sm font-medium text-slate-700">Cancel</button> : null}
            </div>
          </form>
        </ContentCard>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Tenants</h2>
          <div className="mt-4 grid gap-3 md:grid-cols-[minmax(0,1fr)_180px]">
            <input value={tenantSearch} onChange={(event) => setTenantSearch(event.target.value)} placeholder="Search tenant name or invite code" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
            <select value={tenantStatus} onChange={(event) => setTenantStatus(event.target.value as typeof tenantStatus)} className="rounded-xl border border-slate-300 px-4 py-3 text-sm">
              <option value="ALL">All statuses</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </select>
          </div>
          <div className="mt-4 space-y-3">
            {tenantsQuery.data?.length ? tenantsQuery.data.map((tenant) => (
              <button key={tenant.id} type="button" onClick={() => setSelectedTenantId(tenant.id)} className={`w-full rounded-2xl border p-4 text-left transition ${selectedTenantId === tenant.id ? "border-sky-300 bg-sky-50" : "border-slate-200 bg-white hover:border-slate-300"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold text-slate-950">{tenant.name}</p>
                    <p className="mt-1 text-sm text-slate-500">Owner: {tenant.owner?.fullName ?? "Unassigned"}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.2em] text-slate-400">{tenant.plan?.name ?? "No plan assigned"}</p>
                    <p className="mt-2 text-xs text-slate-500">{tenant.usage.usersCount} users | {tenant.usage.coursesCount} courses | {tenant.usage.enrollmentsCount} enrollments</p>
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-medium ${tenant.isActive ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`}>{tenant.isActive ? "Active" : "Inactive"}</span>
                </div>
              </button>
            )) : tenantsQuery.isLoading ? <StatusBanner>Loading tenants...</StatusBanner> : <EmptyState title="No tenants found" description="Tenant search will populate here when matching organizations exist." />}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Tenant Detail</h2>
          {tenantDetailQuery.data ? (
            <div className="mt-4 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xl font-semibold text-slate-950">{tenantDetailQuery.data.name}</p>
                  <p className="mt-1 text-sm text-slate-500">Invite Code: {tenantDetailQuery.data.inviteCode}</p>
                  <p className="mt-1 text-sm text-slate-500">
                    Current Plan: {tenantDetailQuery.data.subscription?.currentSubscription?.plan.name ?? tenantDetailQuery.data.subscription?.latestSubscription?.plan.name ?? "No plan assigned"}
                  </p>
                </div>
                <button type="button" onClick={() => tenantStatusMutation.mutate({ id: tenantDetailQuery.data.id, isActive: !tenantDetailQuery.data.isActive })} className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700">
                  {tenantDetailQuery.data.isActive ? "Deactivate" : "Reactivate"}
                </button>
              </div>
              <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_180px_auto]">
                <select value={tenantPlanId} onChange={(event) => setTenantPlanId(event.target.value)} className="rounded-xl border border-slate-300 px-4 py-3 text-sm">
                  <option value="">Choose a plan</option>
                  {plansQuery.data?.filter((plan) => !plan.isArchived).map((plan) => <option key={plan.id} value={plan.id}>{plan.name} ({plan.code})</option>)}
                </select>
                <select value={tenantBillingPeriod} onChange={(event) => setTenantBillingPeriod(event.target.value as "MONTHLY" | "YEARLY")} className="rounded-xl border border-slate-300 px-4 py-3 text-sm">
                  <option value="MONTHLY">Monthly</option>
                  <option value="YEARLY">Yearly</option>
                </select>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => tenantPlanId && upsertTenantSubscriptionMutation.mutate({ tenantId: tenantDetailQuery.data.id, planId: tenantPlanId, billingPeriod: tenantBillingPeriod })}
                    disabled={!tenantPlanId}
                    className="rounded-full bg-slate-950 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
                  >
                    Activate
                  </button>
                  <button
                    type="button"
                    onClick={() => tenantPlanId && upsertTenantSubscriptionMutation.mutate({ tenantId: tenantDetailQuery.data.id, planId: tenantPlanId, billingPeriod: "MONTHLY", isTrial: true })}
                    disabled={!tenantPlanId}
                    className="rounded-full border border-sky-300 px-4 py-2 text-sm font-medium text-sky-700 disabled:opacity-50"
                  >
                    Restart trial
                  </button>
                  <button
                    type="button"
                    onClick={() => updateTenantSubscriptionMutation.mutate({ tenantId: tenantDetailQuery.data.id, markCanceled: true })}
                    className="rounded-full border border-rose-300 px-4 py-2 text-sm font-medium text-rose-700"
                  >
                    End current
                  </button>
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                  <p className="font-medium text-slate-900">Usage</p>
                  <p className="mt-2">{tenantDetailQuery.data.usage.usersCount} users</p>
                  <p>{tenantDetailQuery.data.usage.studentsCount ?? 0} students</p>
                  <p>{tenantDetailQuery.data.usage.instructorsCount ?? 0} instructors</p>
                  <p>{tenantDetailQuery.data.usage.adminsCount ?? 0} admins</p>
                  <p>{tenantDetailQuery.data.usage.coursesCount} courses</p>
                  <p>{money.format(tenantDetailQuery.data.usage.approvedRevenue ?? 0)} approved revenue</p>
                </div>
                <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                  <p className="font-medium text-slate-900">Subscription</p>
                  <p className="mt-2">State: {tenantDetailQuery.data.subscription?.currentSubscription?.state ?? tenantDetailQuery.data.subscription?.latestSubscription?.state ?? "NONE"}</p>
                  <p>Trial days remaining: {tenantDetailQuery.data.subscription?.daysRemaining ?? 0}</p>
                  <p>Freeze creation: {tenantDetailQuery.data.subscription?.freezeCreation ? "Yes" : "No"}</p>
                  <p>Limit snapshot: {tenantDetailQuery.data.plan?.maxCourses ?? tenantDetailQuery.data.subscription?.trialRules.maxCourses ?? "—"} courses</p>
                  <p>Student cap: {tenantDetailQuery.data.plan?.maxStudentsTotal ?? tenantDetailQuery.data.subscription?.trialRules.maxStudentsTotal ?? "—"}</p>
                </div>
              </div>
            </div>
          ) : tenantDetailQuery.isLoading ? <StatusBanner>Loading tenant detail...</StatusBanner> : <EmptyState title="Select a tenant" description="Choose a tenant from the list to inspect its plan and usage." />}
        </ContentCard>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Users</h2>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <input value={userSearch} onChange={(event) => setUserSearch(event.target.value)} placeholder="Search name or email" className="rounded-xl border border-slate-300 px-4 py-3 text-sm" />
            <select value={userRole} onChange={(event) => setUserRole(event.target.value as typeof userRole)} className="rounded-xl border border-slate-300 px-4 py-3 text-sm">
              <option value="ALL">All roles</option>
              <option value="ADMIN">Admin</option>
              <option value="INSTRUCTOR">Instructor</option>
              <option value="STUDENT">Student</option>
            </select>
            <select value={userStatus} onChange={(event) => setUserStatus(event.target.value as typeof userStatus)} className="rounded-xl border border-slate-300 px-4 py-3 text-sm">
              <option value="ALL">All statuses</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </select>
          </div>
          <div className="mt-4 space-y-3">
            {usersQuery.data?.length ? usersQuery.data.map((user) => (
              <button key={user.id} type="button" onClick={() => setSelectedUserId(user.id)} className={`w-full rounded-2xl border p-4 text-left transition ${selectedUserId === user.id ? "border-sky-300 bg-sky-50" : "border-slate-200 bg-white hover:border-slate-300"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold text-slate-950">{user.fullName}</p>
                    <p className="mt-1 text-sm text-slate-500">{user.email}</p>
                    <p className="mt-2 text-xs text-slate-500">{user.role} | {user.tenant?.name ?? "No tenant"}</p>
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-medium ${user.isActive ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`}>{user.isActive ? "Active" : "Inactive"}</span>
                </div>
              </button>
            )) : usersQuery.isLoading ? <StatusBanner>Loading users...</StatusBanner> : <EmptyState title="No users found" description="Adjust the filters to surface users here." />}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">User Detail</h2>
          {userDetailQuery.data ? (
            <div className="mt-4 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xl font-semibold text-slate-950">{userDetailQuery.data.user.fullName}</p>
                  <p className="mt-1 text-sm text-slate-500">{userDetailQuery.data.user.email}</p>
                </div>
                <button type="button" onClick={() => userStatusMutation.mutate({ id: userDetailQuery.data.user.id, isActive: !userDetailQuery.data.user.isActive })} className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700">
                  {userDetailQuery.data.user.isActive ? "Deactivate" : "Reactivate"}
                </button>
              </div>
              <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                <p>Role: {userDetailQuery.data.user.role}</p>
                <p>Tenant: {userDetailQuery.data.user.tenant?.name ?? "No tenant"}</p>
                <p>Enrollments: {userDetailQuery.data.user._count.enrollments}</p>
                <p>Courses: {userDetailQuery.data.user._count.instructorCourses}</p>
              </div>
            </div>
          ) : userDetailQuery.isLoading ? <StatusBanner>Loading user detail...</StatusBanner> : <EmptyState title="Select a user" description="Choose a user from the list to inspect account state." />}
        </ContentCard>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-2">
        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Platform Courses</h2>
          <div className="mt-4 space-y-3">
            {coursesQuery.data?.length ? coursesQuery.data.slice(0, 10).map((course) => (
              <div key={course.id} className="rounded-2xl border border-slate-200 p-4">
                <p className="font-semibold text-slate-950">{course.title}</p>
                <p className="mt-1 text-sm text-slate-500">{course.instructor.fullName} | {course.tenant.name}</p>
                <p className="mt-2 text-xs text-slate-500">{course._count.enrollments} enrollments | {course._count.reviews} reviews | {course.status}</p>
              </div>
            )) : coursesQuery.isLoading ? <StatusBanner>Loading courses...</StatusBanner> : <EmptyState title="No courses yet" description="Course oversight will appear here when courses exist." />}
          </div>
        </ContentCard>

        <ContentCard className="p-6">
          <h2 className="text-lg font-semibold text-slate-950">Platform Payments</h2>
          <div className="mt-4 space-y-3">
            {paymentsQuery.data?.length ? paymentsQuery.data.slice(0, 10).map((payment) => (
              <div key={payment.id} className="rounded-2xl border border-slate-200 p-4">
                <p className="font-semibold text-slate-950">{payment.course.title}</p>
                <p className="mt-1 text-sm text-slate-500">{payment.user.fullName} | {payment.tenant.name}</p>
                <p className="mt-2 text-xs text-slate-500">{payment.method.label} | {money.format(payment.amount)} | {payment.status}</p>
              </div>
            )) : paymentsQuery.isLoading ? <StatusBanner>Loading payments...</StatusBanner> : <EmptyState title="No payments yet" description="Payment oversight will appear here when transactions exist." />}
          </div>
        </ContentCard>
      </div>

      <ContentCard className="mt-8 p-6">
        <h2 className="text-lg font-semibold text-slate-950">Recent Platform Activity</h2>
        {activityQuery.data ? (
          <div className="mt-4 grid gap-4 xl:grid-cols-4">
            <div><p className="text-sm font-medium text-slate-900">Users</p><div className="mt-3 space-y-2">{activityQuery.data.recentUsers.map((item) => <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">{item.fullName} | {item.role}</div>)}</div></div>
            <div><p className="text-sm font-medium text-slate-900">Courses</p><div className="mt-3 space-y-2">{activityQuery.data.recentCourses.map((item) => <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">{item.title} | {item.status}</div>)}</div></div>
            <div><p className="text-sm font-medium text-slate-900">Payments</p><div className="mt-3 space-y-2">{activityQuery.data.recentPayments.map((item) => <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">{item.user.fullName} | {item.course.title}</div>)}</div></div>
            <div><p className="text-sm font-medium text-slate-900">Notifications</p><div className="mt-3 space-y-2">{activityQuery.data.recentNotifications.map((item) => <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">{item.title}</div>)}</div></div>
          </div>
        ) : activityQuery.isLoading ? <StatusBanner>Loading activity...</StatusBanner> : <EmptyState title="No recent activity" description="Platform activity will populate here as the system is used." />}
      </ContentCard>
    </PageShell>
  );
}
