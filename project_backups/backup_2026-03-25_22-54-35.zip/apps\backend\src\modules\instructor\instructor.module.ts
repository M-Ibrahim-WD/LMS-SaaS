import { Module } from "@nestjs/common";
import { InstructorController } from "./controllers/instructor.controller";
import { InstructorService } from "./services/instructor.service";

@Module({
  controllers: [InstructorController],
  providers: [InstructorService]
})
export class InstructorModule {}
