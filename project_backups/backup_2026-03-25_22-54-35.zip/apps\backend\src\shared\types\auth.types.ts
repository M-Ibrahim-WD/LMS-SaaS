export type UserRole = "ADMIN" | "INSTRUCTOR" | "STUDENT";

export interface JwtPayload {
  sub: string;
  tenantId: string | null;
  role: UserRole;
  email: string;
}
