import { Module } from "@nestjs/common";
import { CertificatesController } from "./controllers/certificates.controller";
import { CertificatesPublicController } from "./controllers/certificates-public.controller";
import { CertificatesService } from "./services/certificates.service";

@Module({
  controllers: [CertificatesController, CertificatesPublicController],
  providers: [CertificatesService],
  exports: [CertificatesService]
})
export class CertificatesModule {}
