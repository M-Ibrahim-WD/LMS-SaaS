import { Module } from "@nestjs/common";
import { StudentInstructorsController } from "./controllers/student-instructors.controller";
import { StudentInstructorsService } from "./services/student-instructors.service";

@Module({
  controllers: [StudentInstructorsController],
  providers: [StudentInstructorsService],
  exports: [StudentInstructorsService]
})
export class StudentInstructorsModule {}
