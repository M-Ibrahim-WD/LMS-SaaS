import { ConflictException, Injectable } from "@nestjs/common";
import { PrismaService } from "../../../shared/prisma/prisma.service";
import { UserRole } from "@prisma/client";
import * as bcrypt from "bcrypt";
import { UpdateProfileDto } from "../dto/update-profile.dto";

interface CreateUserInput {
  email: string;
  fullName: string;
  password: string;
  role: UserRole | "INSTRUCTOR" | "STUDENT" | "ADMIN";
  tenantId: string | null;
}

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private normalizeEmail(email: string) {
    return email.trim().toLowerCase();
  }

  private readonly userSelect = {
    id: true,
    email: true,
    fullName: true,
    bio: true,
    profileImage: true,
    role: true,
    tenantId: true,
    tenant: {
      select: {
        id: true,
        name: true
      }
    },
    createdAt: true,
    updatedAt: true
  };

  findById(id: string, tenantId: string | null) {
    return this.prisma.user.findFirst({
      where: tenantId ? { id, tenantId } : { id },
      select: this.userSelect
    });
  }

  findAuthUserByEmail(email: string) {
    return this.prisma.user.findUnique({
      where: {
        email: this.normalizeEmail(email)
      }
    });
  }

  async create(data: CreateUserInput) {
    const password = await bcrypt.hash(data.password, 10);

    try {
      return await this.prisma.user.create({
        data: {
          email: this.normalizeEmail(data.email),
          fullName: data.fullName,
          role: data.role as UserRole,
          tenantId: data.tenantId,
          password
        },
        select: this.userSelect
      });
    } catch {
      throw new ConflictException("User with this email already exists");
    }
  }

  getProfile(userId: string, tenantId: string | null) {
    return this.findById(userId, tenantId);
  }

  async getProfileSummary(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        fullName: true,
        email: true,
        bio: true,
        profileImage: true,
        role: true,
        createdAt: true,
        tenant: {
          select: {
            id: true,
            name: true
          }
        },
        _count: {
          select: {
            instructorCourses: true,
            followedByStudents: true,
            joinedInstructors: true,
            certificates: true,
            enrollments: true
          }
        }
      }
    });

    if (!user) {
      return null;
    }

    return {
      ...user,
      stats:
        user.role === "INSTRUCTOR"
          ? {
              studentsCount: user._count.followedByStudents,
              coursesCount: user._count.instructorCourses
            }
          : {
              coursesCount: user._count.enrollments,
              certificatesCount: user._count.certificates,
              followingCount: user._count.joinedInstructors
            }
    };
  }

  async updateProfile(userId: string, tenantId: string | null, dto: UpdateProfileDto) {
    const data: { fullName?: string; bio?: string | null; profileImage?: string | null; password?: string } = {};

    if (dto.fullName) {
      data.fullName = dto.fullName;
    }

    if (dto.bio !== undefined) {
      data.bio = dto.bio.trim() || null;
    }

    if (dto.profileImage !== undefined) {
      data.profileImage = dto.profileImage.trim() || null;
    }

    if (dto.password) {
      data.password = await bcrypt.hash(dto.password, 10);
    }

    const target = await this.prisma.user.findFirst({
      where: tenantId ? { id: userId, tenantId } : { id: userId },
      select: { id: true }
    });

    if (!target) {
      return null;
    }

    return this.prisma.user.update({
      where: { id: target.id },
      data,
      select: this.userSelect
    });
  }

  async assignTenant(userId: string, tenantId: string) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { tenantId },
      select: this.userSelect
    });
  }
}
